# NAS – Ned Adventure Society (MERN)

Public website + admin portal. MongoDB · Express · React (Vite) · Node.

## Run locally
Requires Node 20+ and MongoDB (local `mongod` or a free MongoDB Atlas URI).

```bash
# 1. API
cd server
cp .env.example .env        # set MONGO_URI, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
npm run seed                # creates the admin + default site text
npm run seed -- --sample    # optional: demo events/team/sponsors (wipes those collections!)
npm run dev                 # http://localhost:5000

# 2. Website (new terminal)
cd client
npm run dev                 # http://localhost:5173 (proxies /api and /uploads to :5000)
```
Admin portal: http://localhost:5173/admin/login

## Admin can manage
Events (cover, date, upcoming/past/draft, Google Form link), Gallery (multi photo/video upload, move/delete),
Team, Sponsors (slider order), Announcements (pin/publish), Site Content (hero, About, vision/mission, FAQs,
contact + socials, password change), and Contact-form messages.

## Deployment notes
- Uploads go to `server/uploads` on disk. On hosts with ephemeral disks, switch to Cloudinary/S3 or use a persistent volume.
- Set `CLIENT_ORIGIN` on the API and `VITE_API_URL` on the client if they live on different domains.
- Use a long random `JWT_SECRET` and change the seeded admin password after first login.
