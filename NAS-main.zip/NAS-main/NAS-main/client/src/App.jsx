import { Routes, Route, Navigate } from 'react-router-dom';
import PublicLayout from './components/PublicLayout.jsx';
import Home from './pages/Home.jsx';
import Events from './pages/Events.jsx';
import Gallery from './pages/Gallery.jsx';
import About from './pages/About.jsx';
import Team from './pages/Team.jsx';
import Contact from './pages/Contact.jsx';
import AdminLayout from './pages/admin/AdminLayout.jsx';
import Login from './pages/admin/Login.jsx';
import Dashboard from './pages/admin/Dashboard.jsx';
import { EventsAdmin, TeamAdmin, SponsorsAdmin, AnnouncementsAdmin } from './pages/admin/Resources.jsx';
import GalleryAdmin from './pages/admin/GalleryAdmin.jsx';
import SiteContentAdmin from './pages/admin/SiteContentAdmin.jsx';
import Messages from './pages/admin/Messages.jsx';
import Forms from './pages/admin/Forms.jsx';
import FormBuilder from './pages/admin/FormBuilder.jsx';
import PublicForm from './pages/PublicForm.jsx';
import FormResponses from './pages/admin/FormResponses.jsx';


export default function App() {
  return (
    <Routes>
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/forms/:slug" element={<PublicForm />} />
        <Route path="/events" element={<Events />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/about" element={<About />} />
        <Route path="/team" element={<Team />} />
        <Route path="/contact" element={<Contact />} />
      </Route>
      <Route path="/admin/login" element={<Login />} />
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="events" element={<EventsAdmin />} />
        <Route path="gallery" element={<GalleryAdmin />} />
        <Route path="team" element={<TeamAdmin />} />
        <Route path="sponsors" element={<SponsorsAdmin />} />
        <Route path="announcements" element={<AnnouncementsAdmin />} />
        <Route path="content" element={<SiteContentAdmin />} />
        <Route path="messages" element={<Messages />} />
        <Route path="forms" element={<Forms />} />
        <Route path="forms/:id" element={<FormBuilder />} />
        <Route path="forms/:id/responses" element={<FormResponses />} />
      </Route>
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}
