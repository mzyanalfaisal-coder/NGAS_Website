import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { fmtDate } from '../lib/api';

export default function ActiveForms() {
  const [forms, setForms] = useState([]);

  useEffect(() => {
    // Backend se published forms fetch karein
    fetch('http://localhost:5000/api/public/forms')
      .then(res => res.json())
      .then(data => setForms(data))
      .catch(console.error);
  }, []);

  if (forms.length === 0) return null; // Agar koi form publish nahi hai to kuch na dikhayein

  return (
    <section className="section" style={{ background: 'var(--bg)' }}>
      <div className="container">
        <div className="sec-head">
          <div>
            <span className="eyebrow">Registration Open</span>
            <h2>Active Forms</h2>
          </div>
        </div>
        
        <div className="grid-3" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '24px' }}>
          {forms.map(form => (
            <div key={form._id} className="card pad" style={{ display: 'flex', flexDirection: 'column', borderTop: '6px solid var(--blue)' }}>
              {form.eventName && <span className="chip chip-solid" style={{ alignSelf: 'flex-start', marginBottom: '12px' }}>{form.eventName}</span>}
              <h3 style={{ marginBottom: '8px' }}>{form.title}</h3>
              {form.eventDate && <p className="muted text-sm" style={{ marginBottom: '8px' }}>📅 {fmtDate(form.eventDate)}</p>}
              {form.description && <p className="muted text-sm" style={{ flex: 1, marginBottom: '16px' }}>{form.description}</p>}
              
              <Link to={`/forms/${form.slug}`} className="btn btn-primary" style={{ width: '100%', marginTop: 'auto' }}>
                Fill Form Now →
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}