import { useEffect, useState } from 'react';
import { NavLink, Link, Outlet, useLocation } from 'react-router-dom';
import { useFetch } from '../lib/hooks';

const LINKS = [['/', 'Home'], ['/events', 'Events'], ['/gallery', 'Gallery'], ['/about', 'About Us'], ['/team', 'Team'], ['/contact', 'Contact Us']];

export function Logo({ dark }) {
  return (
    <Link to="/" className={`logo ${dark ? 'dark' : ''}`}>
      <img className="logo-img" src="/logo.png" alt="NGAS - NED Girls Affairs Society" />
    </Link>
  );
}

export default function PublicLayout() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const { data: c } = useFetch('/content');
  useEffect(() => { setOpen(false); window.scrollTo(0, 0); }, [pathname]);
  const ct = c?.contact || {};
  return (
    <>
      <header className="nav">
        <div className="container nav-in">
          <Logo />
          <nav className={`nav-links ${open ? 'open' : ''}`}>
            {LINKS.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'}>{label}</NavLink>)}
            <Link to="/contact" className="btn btn-primary btn-sm nav-cta">Join the Society</Link>
          </nav>
          <button className="burger" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? '✕' : <><i /><i /><i /></>}</button>
          <img className="logo-img partner-logo" src="/te-links-logo.png" alt="TE Links logo" />
        </div>
      </header>
      <main><Outlet /></main>
      <footer className="footer">
        <div className="container footer-in">
          <div className="footer-brand">
            <Logo dark />
            <p>A student society of NED University that turns weekends into expeditions — treks, road trips, camps and community drives.</p>
          </div>
          <div><h4>Explore</h4>{LINKS.slice(0, 5).map(([to, l]) => <Link key={to} to={to}>{l}</Link>)}</div>
          <div><h4>Get in touch</h4><span>{ct.email}</span><span>{ct.phone}</span><span>{ct.address}</span></div>
          <div><h4>Follow us</h4>
            {[['instagram', 'Instagram'], ['linkedin', 'LinkedIn'], ['facebook', 'Facebook'], ['youtube', 'YouTube']].map(([k, l]) => ct[k] ? <a key={k} href={ct[k]} target="_blank" rel="noreferrer">{l}</a> : null)}
          </div>
        </div>
        <div className="container footer-bottom">© {new Date().getFullYear()} NED Girls Affairs Society · NED University of Engineering &amp; Technology</div>
      </footer>
    </>
  );
}
