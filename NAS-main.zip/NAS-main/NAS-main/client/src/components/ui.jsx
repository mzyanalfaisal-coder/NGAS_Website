import { asset } from '../lib/api';
export const Img = ({ src, alt = '', className = '' }) =>
  src ? <img className={className} src={asset(src)} alt={alt} loading="lazy" /> : <div className={`ph ${className}`} aria-hidden />;
// Zooms a sponsor logo into the admin-chosen focus point
export const logoStyle = (focus = '50% 50%', zoom = 1) => ({ objectPosition: focus, transformOrigin: focus, transform: `scale(${zoom || 1})` });
export const PageHead = ({ eyebrow, title, sub, children }) => (
  <section className="page-head"><div className="container">
    <span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{sub && <p className="lead">{sub}</p>}{children}
  </div></section>
);
export const Section = ({ eyebrow, title, link, children, className = '' }) => (
  <section className={`section ${className}`}><div className="container">
    {(title || link) && <div className="sec-head"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h2>{title}</h2></div>{link}</div>}
    {children}
  </div></section>
);
export const State = ({ loading, error, empty, children }) =>
  loading ? <p className="muted state">Loading…</p> : error ? <p className="error state">{error}</p> : empty ? <p className="muted state">{empty}</p> : children;
