import { Link } from 'react-router-dom';
import { useFetch } from '../lib/hooks';
import { asset, dateRange, daysLabel, fmtDate } from '../lib/api';
import { Img, Section, State, logoStyle } from '../components/ui.jsx';
import ActiveForms from '../components/ActiveForms';

export default function Home() {
  const { data: c } = useFetch('/content');
  const { data: sponsors } = useFetch('/sponsors');
  const ev = useFetch('/events');
  const ann = useFetch('/announcements');
  const upcoming = (ev.data || []).filter((e) => e.status === 'upcoming').slice(0, 4);
  const hero = c?.heroImage ? { backgroundImage: `url(${asset(c.heroImage)})`, backgroundPosition: c.heroFocus || 'center' } : {};
  const logos = sponsors || [];
  const loop = logos.length ? [...logos, ...logos, ...logos, ...logos].slice(0, Math.max(logos.length * 2, 12)) : [];
  return (
    <>
      <section className="hero" style={hero}>
        <div className="hero-shade" />
        <div className="container hero-in">
          <h2 className="chip-pill"><i />NED GIRLS AFFAIRS SOCIETY</h2>
          <h1 style={{ fontFamily: 'Arial, sans-serif', fontStyle: 'italic' }}>{'# JUROGAY TOU JANOGAY'}</h1>
          <p className="lead">{c?.heroSub}</p>
          <div className="row">
            <Link to="/events" className="btn btn-primary">Explore Events</Link>
            <Link to="/gallery" className="btn btn-ghost">Watch the Gallery</Link>
          </div>
          <div className="stats">{(c?.stats || []).map((s, i) => <div key={i}><b>{s.value}</b><span>{s.label}</span></div>)}</div>
        </div>
      </section>

      {logos.length > 0 && (
        <section className="sponsors">
          <p className="eyebrow center">OUR SPONSORS · TRUSTED BY BRANDS THAT BACK ADVENTURE</p>
          <div className="marquee"><div className="marquee-track" style={{ '--n': loop.length / 2 }}>
            {[...loop, ...loop].map((s, i) => {
              const inner = s.logo ? <img src={asset(s.logo)} alt={s.name} style={logoStyle(s.logoFocus, s.logoZoom)} /> : <span>{s.name}</span>;
              const url = s.website?.trim();
              return url
                ? <a key={i} className="sponsor" href={/^https?:\/\//i.test(url) ? url : `https://${url}`} target="_blank" rel="noreferrer" title={s.name}>{inner}</a>
                : <div key={i} className="sponsor" title={s.name}>{inner}</div>;
            })}
          </div></div>
        </section>
      )}

      <Section eyebrow="What’s next" title="Upcoming Events" link={<Link className="link" to="/events">View all events →</Link>} className="alt">
        <div className="home-split">
          <div className="stack">
            <State loading={ev.loading} error={ev.error} empty={!upcoming.length && 'No upcoming events yet — check back soon.'}>
              {upcoming.map((e) => (
                <Link key={e._id} to={`/events?open=${e._id}`} className="ev-row card">
                  <Img src={e.coverImage} alt={e.title} />
                  <div><span className="chip">{dateRange(e.date, e.duration, { year: false }).toUpperCase()}</span><h3>{e.title}</h3>
                    <p className="muted">{[e.venue, daysLabel(e.duration), e.fee].filter(Boolean).join(' · ')}</p>
                    <span className="link">View details →</span></div>
                </Link>
              ))}
            </State>
          </div>
          <aside className="ann">
            <div className="ann-head"><h3>Announcements</h3>{(ann.data || []).length > 0 && <span className="badge">{ann.data.length} NEW</span>}</div>
            <State loading={ann.loading} error={ann.error} empty={!(ann.data || []).length && 'No announcements right now.'}>
              {(ann.data || []).slice(0, 5).map((a) => (
                <div key={a._id} className="ann-item"><i />
                  <div><small>{fmtDate(a.date, { day: 'numeric', month: 'short' }).toUpperCase()}{a.pinned ? ' · PINNED' : ''}</small>
                    <b>{a.title}</b>{a.message && <p className="muted">{a.message}</p>}</div></div>
              ))}
            </State>
          </aside>
        </div>
      </Section>
    </>
  );
}
