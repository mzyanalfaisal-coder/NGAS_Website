import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

export default function PublicForm() {
  const { slug } = useParams();
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [answers, setAnswers] = useState({});
  const [files, setFiles] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});

  useEffect(() => {
    fetch(`http://localhost:5000/api/public/forms/${slug}`)
      .then(res => res.json())
      .then(data => {
        if (data.error) throw new Error(data.error);
        setForm(data);
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [slug]);

  const handleChange = (fieldId, value) => {
    setAnswers(prev => ({ ...prev, [fieldId]: value }));
    if (fieldErrors[fieldId]) setFieldErrors(prev => ({ ...prev, [fieldId]: null }));
  };

  const handleFileChange = (fieldId, file) => {
    setFiles(prev => ({ ...prev, [fieldId]: file }));
    if (fieldErrors[fieldId]) setFieldErrors(prev => ({ ...prev, [fieldId]: null }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setFieldErrors({});
    
    try {
      const formData = new FormData();
      
      // Add text/number answers
      Object.keys(answers).forEach(key => {
        formData.append(key, answers[key]);
      });
      
      // Add files
      Object.keys(files).forEach(key => {
        if (files[key]) formData.append(key, files[key]);
      });

      const res = await fetch(`http://localhost:5000/api/public/forms/${slug}/submit`, {
        method: 'POST',
        body: formData // FormData automatically sets correct headers
      });
      
      const data = await res.json();
      
      if (!res.ok) {
        if (data.fields) setFieldErrors(data.fields);
        throw new Error(data.error || 'Submission failed');
      }
      setSubmitted(true);
    } catch (err) {
      if (!Object.keys(fieldErrors).length) setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="container section"><p>Loading form...</p></div>;
  if (error) return <div className="container section"><p className="error">{error}</p></div>;
  if (!form) return null;

  if (form.closed) {
    return (
      <div className="container section" style={{ textAlign: 'center', padding: '100px 20px' }}>
        <h1>Registration Closed</h1>
        <p className="muted">This registration form is no longer accepting responses.</p>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="container section" style={{ textAlign: 'center', padding: '100px 20px' }}>
        <div className="card pad" style={{ maxWidth: '600px', margin: '0 auto' }}>
          <h1 className="ok">Registration submitted successfully!</h1>
          <p className="muted" style={{ marginTop: '16px' }}>Thank you for registering with NGAS. Your response has been recorded.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container section" style={{ maxWidth: '800px', padding: '40px 20px' }}>
      <div className="card" style={{ borderTop: '8px solid var(--blue)' }}>
        <div className="pad">
          {form.eventName && <span className="eyebrow">{form.eventName}</span>}
          <h1 style={{ marginTop: '8px' }}>{form.title}</h1>
          {form.description && <p className="muted" style={{ marginTop: '12px' }}>{form.description}</p>}
        </div>
      </div>

      <form onSubmit={handleSubmit} style={{ marginTop: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        {form.fields?.map(field => {
          if (field.type === 'section') {
            return <h3 key={field.id} style={{ marginTop: '24px', borderBottom: '1px solid var(--line)', paddingBottom: '8px' }}>{field.label}</h3>;
          }

          const err = fieldErrors[field.id];
          const inputStyle = { width: '100%', padding: '12px', border: '1px solid var(--line)', borderRadius: '8px', outline: 'none' };

          return (
            <div key={field.id} className="card pad">
              <label style={{ fontWeight: '600', display: 'block', marginBottom: '8px' }}>
                {field.label} {field.required && <span className="error">*</span>}
              </label>
              {field.description && <p className="muted text-sm" style={{ marginBottom: '12px' }}>{field.description}</p>}

              {field.type === 'shortText' && <input type="text" style={inputStyle} placeholder={field.placeholder} onChange={e => handleChange(field.id, e.target.value)} required={field.required} />}
              {field.type === 'longText' && <textarea style={{ ...inputStyle, minHeight: '100px', resize: 'vertical' }} placeholder={field.placeholder} onChange={e => handleChange(field.id, e.target.value)} required={field.required} />}
              {field.type === 'email' && <input type="email" style={inputStyle} placeholder={field.placeholder} onChange={e => handleChange(field.id, e.target.value)} required={field.required} />}
              {field.type === 'phone' && <input type="tel" style={inputStyle} placeholder={field.placeholder} onChange={e => handleChange(field.id, e.target.value)} required={field.required} />}
              
              {field.type === 'number' && (
                <input type="number" style={inputStyle} min={field.min} max={field.max} placeholder={field.placeholder} onChange={e => handleChange(field.id, e.target.value)} required={field.required} />
              )}
              
              {field.type === 'date' && (
                <input type="date" style={inputStyle} min={field.minDate} max={field.maxDate} onChange={e => handleChange(field.id, e.target.value)} required={field.required} />
              )}
              
              {field.type === 'rating' && (
                <input type="number" style={inputStyle} min={field.min || 1} max={field.max || 5} placeholder="Rate 1-5" onChange={e => handleChange(field.id, e.target.value)} required={field.required} />
              )}

              {field.type === 'file' && (
                <div>
                  <input 
                    type="file" 
                    accept={(field.fileTypes || []).join(',')}
                    onChange={e => handleFileChange(field.id, e.target.files[0])} 
                    required={field.required}
                    style={{ ...inputStyle, background: 'var(--bg)' }}
                  />
                  <small className="muted" style={{ display: 'block', marginTop: '6px' }}>
                    Allowed: {field.fileTypes?.join(', ') || 'Any file'} 
                    {field.maxFileSize ? ` (Max ${field.maxFileSize / (1024 * 1024)} MB)` : ''}
                  </small>
                </div>
              )}
              
              {field.type === 'dropdown' && (
                <select style={inputStyle} onChange={e => handleChange(field.id, e.target.value)} required={field.required}>
                  <option value="">Select an option...</option>
                  {field.options?.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              )}

              {field.type === 'multipleChoice' && field.options?.map(o => (
                <label key={o} style={{ display: 'block', marginBottom: '8px', fontWeight: 'normal' }}>
                  <input type="radio" name={field.id} value={o} onChange={e => handleChange(field.id, e.target.value)} required={field.required} style={{ marginRight: '8px' }} /> {o}
                </label>
              ))}

              {field.type === 'checkboxes' && field.options?.map(o => {
                const selected = answers[field.id] || [];
                return (
                  <label key={o} style={{ display: 'block', marginBottom: '8px', fontWeight: 'normal' }}>
                    <input 
                      type="checkbox" 
                      value={o} 
                      checked={selected.includes(o)}
                      onChange={e => {
                        const newVal = e.target.checked ? [...selected, o] : selected.filter(x => x !== o);
                        handleChange(field.id, newVal);
                      }} 
                      style={{ marginRight: '8px' }}
                    /> {o}
                  </label>
                );
              })}

              {field.type === 'consent' && (
                <label style={{ display: 'flex', gap: '8px', alignItems: 'center', fontWeight: 'normal' }}>
                  <input type="checkbox" onChange={e => handleChange(field.id, e.target.checked)} required={field.required} /> I agree
                </label>
              )}

              {err && <p className="error" style={{ marginTop: '8px', fontSize: '0.85rem' }}>{err}</p>}
            </div>
          );
        })}

        <button type="submit" className="btn btn-primary" disabled={submitting} style={{ padding: '16px', fontSize: '1.1rem' }}>
          {submitting ? 'Submitting...' : 'Submit Registration'}
        </button>
      </form>
    </div>
  );
}