import { useEffect, useState } from 'react';
import { NavLink, Outlet, Navigate, useNavigate } from 'react-router-dom';
import { api, getToken, setToken } from '../../lib/api';

const NAV = [['/admin', 'Dashboard'], ['/admin/forms', 'Forms'], ['/admin/events', 'Events'], ['/admin/gallery', 'Gallery'], ['/admin/team', 'Team'],
  ['/admin/sponsors', 'Sponsors'], ['/admin/announcements', 'Announcements'], ['/admin/content', 'Site Content'], ['/admin/messages', 'Messages']];
export default function AdminLayout() {
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  useEffect(() => { if (getToken()) api.get('/auth/me').then((r) => setEmail(r.email)).catch(() => {}); }, []);
  if (!getToken()) return <Navigate to="/admin/login" replace />;
  const out = () => { setToken(null); nav('/admin/login'); };
  return (
    <div className="adm">
      <aside className={`adm-side ${open ? 'open' : ''}`}>
        <div className="logo"><img className="logo-img" src="/logo.png" alt="NGAS logo" /><span><b>NGAS</b><small>Admin Portal</small></span></div>
        <nav onClick={() => setOpen(false)}>
          {NAV.map(([to, l]) => <NavLink key={to} to={to} end={to === '/admin'}>{l}</NavLink>)}
        </nav>
        <div className="adm-user"><b>{email || 'NGAS Admin'}</b><a href="/" target="_blank" rel="noreferrer">View site ↗</a><button onClick={out}>Sign out</button></div>
      </aside>
      <div className="adm-main">
        <div className="adm-top"><button className="burger on-adm" onClick={() => setOpen(!open)} aria-label="Menu"><i /><i /><i /></button><b>NGAS Admin</b></div>
        <div className="adm-content"><Outlet /></div>
      </div>
    </div>
  );
}
