import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../../lib/api';

const FIELD_TYPES = [
  { type: 'shortText', label: 'Short Answer' },
  { type: 'longText', label: 'Long Answer / Paragraph' },
  { type: 'email', label: 'Email' },
  { type: 'phone', label: 'Phone Number' },
  { type: 'number', label: 'Number' },
  { type: 'dropdown', label: 'Dropdown' },
  { type: 'multipleChoice', label: 'Multiple Choice' },
  { type: 'checkboxes', label: 'Checkboxes' },
  { type: 'date', label: 'Date' },
  { type: 'file', label: 'File Upload' },
  { type: 'rating', label: 'Rating' },
  { type: 'section', label: 'Section / Divider' },
  { type: 'consent', label: 'Consent / Terms checkbox' }
];

export default function FormBuilder() {
  const { id } = useParams();
  const nav = useNavigate();
  
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [selectedFieldId, setSelectedFieldId] = useState(null);

  // Load form data
  useEffect(() => {
    api.get(`/forms/${id}`)
      .then(res => setForm(res))
      .catch(err => setMsg(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <p className="muted state">Loading...</p>;
  if (!form) return <p className="error state">{msg || 'Form not found'}</p>;

  // Handle Title/Desc changes
  const updateFormMeta = (key, value) => setForm(prev => ({ ...prev, [key]: value }));

  // Add new field
  const addField = (type) => {
    const newField = {
      id: `field_${Date.now()}`,
      type,
      label: FIELD_TYPES.find(f => f.type === type)?.label || 'Untitled Question',
      required: false,
      options: ['Option 1', 'Option 2']
    };
    setForm(prev => ({ ...prev, fields: [...(prev.fields || []), newField] }));
    setSelectedFieldId(newField.id);
  };

  // Update a specific field
  const updateField = (fieldId, key, value) => {
    setForm(prev => ({
      ...prev,
      fields: prev.fields.map(f => f.id === fieldId ? { ...f, [key]: value } : f)
    }));
  };

  // Delete field
  const deleteField = (fieldId) => {
    if (!window.confirm('Delete this question?')) return;
    setForm(prev => ({ ...prev, fields: prev.fields.filter(f => f.id !== fieldId) }));
    if (selectedFieldId === fieldId) setSelectedFieldId(null);
  };

  // Duplicate field
  const duplicateField = (fieldId) => {
    const field = form.fields.find(f => f.id === fieldId);
    const newField = { ...field, id: `field_${Date.now()}` };
    const idx = form.fields.findIndex(f => f.id === fieldId);
    const newFields = [...form.fields];
    newFields.splice(idx + 1, 0, newField);
    setForm(prev => ({ ...prev, fields: newFields }));
  };

  // Drag & Drop logic
  const handleDragStart = (e, index) => {
    e.dataTransfer.setData('dragIndex', index);
  };
  const handleDrop = (e, dropIndex) => {
    e.preventDefault();
    const dragIndex = Number(e.dataTransfer.getData('dragIndex'));
    if (dragIndex === dropIndex) return;
    const newFields = [...form.fields];
    const [dragged] = newFields.splice(dragIndex, 1);
    newFields.splice(dropIndex, 0, dragged);
    setForm(prev => ({ ...prev, fields: newFields }));
  };

  // Save to backend
  const handleSave = async (publishStatus = null) => {
    setSaving(true); setMsg('');
    try {
      const payload = { ...form, status: publishStatus || form.status };
      delete payload.responseCount;
      delete payload.__v;
      
      const token = localStorage.getItem('nas_token');
      const res = await fetch(`http://localhost:5000/api/forms/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      setForm(data);
      setMsg('Saved successfully!');
      setTimeout(() => setMsg(''), 3000);
    } catch (err) {
      setMsg(err.message);
    } finally {
      setSaving(false);
    }
  };

  const selectedField = form.fields?.find(f => f.id === selectedFieldId);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', height: '100%' }}>
      
      {/* Top Toolbar */}
      <div className="row" style={{ justifyContent: 'space-between', background: '#fff', padding: '12px 24px', borderRadius: '12px', border: '1px solid var(--line)' }}>
        <div className="row" style={{ gap: '16px' }}>
          <button className="btn btn-light btn-sm" onClick={() => nav('/admin/forms')}>← Back</button>
          <input 
            style={{ fontSize: '1.2rem', fontWeight: 'bold', border: 'none', outline: 'none', width: '300px' }}
            value={form.title} 
            onChange={e => updateFormMeta('title', e.target.value)} 
          />
          <span className={`pill ${form.status}`}>{form.status}</span>
        </div>
        <div className="row" style={{ gap: '8px' }}>
          {msg && <span className="ok text-sm">{msg}</span>}
          <button className="btn btn-ghost btn-sm" onClick={() => window.open(`/forms/${form.slug}`, '_blank')}>Preview</button>
          <button className="btn btn-primary btn-sm" disabled={saving} onClick={() => handleSave('published')}>Publish</button>
          <button className="btn btn-light btn-sm" disabled={saving} onClick={() => handleSave()}>Save Draft</button>
        </div>
      </div>

      {/* 3-Panel Builder Layout */}
      <div className="builder-layout">
        
        {/* Left Panel: Field Types */}
        <div className="builder-panel">
          <div className="builder-panel-header">Add Field</div>
          <div className="builder-panel-body">
            {FIELD_TYPES.map(ft => (
              <button key={ft.type} className="field-type-btn" onClick={() => addField(ft.type)}>
                + {ft.label}
              </button>
            ))}
          </div>
        </div>

        {/* Center Panel: Canvas */}
        <div className="builder-panel" style={{ overflowY: 'auto' }}>
          <div className="builder-canvas">
            {/* Form Header (Title/Desc) */}
            <div className="canvas-card" style={{ borderTop: '8px solid var(--blue)' }}>
              <input 
                style={{ fontSize: '1.8rem', fontWeight: 'bold', border: 'none', borderBottom: '1px solid transparent', width: '100%', outline: 'none' }}
                value={form.title} onChange={e => updateFormMeta('title', e.target.value)} 
                onFocus={e => e.target.style.borderBottom = '1px solid var(--line)'}
                onBlur={e => e.target.style.borderBottom = '1px solid transparent'}
              />
              <textarea 
                style={{ width: '100%', border: 'none', outline: 'none', marginTop: '8px', resize: 'none', color: 'var(--muted)' }}
                value={form.description || ''} onChange={e => updateFormMeta('description', e.target.value)} placeholder="Form description..."
              />
            </div>

            {/* Questions List */}
            {form.fields?.map((field, index) => (
              <div 
                key={field.id} 
                className={`canvas-card ${selectedFieldId === field.id ? 'selected' : ''}`}
                onClick={() => setSelectedFieldId(field.id)}
                draggable
                onDragStart={(e) => handleDragStart(e, index)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => handleDrop(e, index)}
              >
                <div className="drag-handle">⋮⋮</div>
                {field.type === 'section' ? (
                  <input 
                    style={{ fontSize: '1.2rem', fontWeight: 'bold', border: 'none', width: '100%', outline: 'none' }}
                    value={field.label} onChange={e => updateField(field.id, 'label', e.target.value)} 
                  />
                ) : (
                  <>
                    <input 
                      style={{ fontSize: '1rem', fontWeight: '600', border: 'none', width: '100%', outline: 'none' }}
                      value={field.label} onChange={e => updateField(field.id, 'label', e.target.value)} 
                    />
                    {field.description && <p className="muted text-sm" style={{ marginTop: '4px' }}>{field.description}</p>}
                    
                    <div style={{ marginTop: '12px', opacity: 0.5, pointerEvents: 'none' }}>
                      <input type="text" placeholder={field.placeholder || "User's answer"} style={{ width: '100%', padding: '10px', borderBottom: '1px solid var(--line)', borderTop: 'none', borderLeft: 'none', borderRight: 'none' }} readOnly />
                    </div>
                  </>
                )}
                
                <div className="card-actions">
                  <button className="chip-btn" onClick={() => duplicateField(field.id)}>Duplicate</button>
                  <button className="chip-btn" onClick={() => deleteField(field.id)}>Delete</button>
                  <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="text-sm muted">Required</span>
                    <input type="checkbox" checked={field.required} onChange={e => updateField(field.id, 'required', e.target.checked)} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Panel: Settings */}
        <div className="builder-panel">
          <div className="builder-panel-header">Question Settings</div>
          <div className="builder-panel-body">
            {!selectedField ? (
              <p className="muted text-sm">Select a question to edit its settings.</p>
            ) : (
              <>
                <div className="setting-group">
                  <label>Question Text</label>
                  <input value={selectedField.label} onChange={e => updateField(selectedField.id, 'label', e.target.value)} />
                </div>
                
                {selectedField.type !== 'section' && (
                  <>
                    <div className="setting-group">
                      <label>Description / Help Text</label>
                      <textarea value={selectedField.description || ''} onChange={e => updateField(selectedField.id, 'description', e.target.value)} />
                    </div>
                    
                    {selectedField.type !== 'file' && (
                      <div className="setting-group">
                        <label>Placeholder</label>
                        <input value={selectedField.placeholder || ''} onChange={e => updateField(selectedField.id, 'placeholder', e.target.value)} />
                      </div>
                    )}

                    {/* File Upload Specific Settings */}
                    {selectedField.type === 'file' && (
                      <>
                        <div className="setting-group">
                          <label>Allowed File Types</label>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', marginTop: '8px' }}>
                            {['.pdf', '.doc', '.docx', '.jpg', '.jpeg', '.png'].map(ext => {
                              const isChecked = (selectedField.fileTypes || []).includes(ext);
                              return (
                                <label key={ext} style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.85rem', fontWeight: 'normal' }}>
                                  <input 
                                    type="checkbox" 
                                    checked={isChecked}
                                    onChange={(e) => {
                                      const current = selectedField.fileTypes || [];
                                      const updated = e.target.checked 
                                        ? [...current, ext] 
                                        : current.filter(t => t !== ext);
                                      updateField(selectedField.id, 'fileTypes', updated);
                                    }} 
                                  />
                                  {ext}
                                </label>
                              );
                            })}
                          </div>
                        </div>
                        <div className="setting-group">
                          <label>Max File Size (MB)</label>
                          <input 
                            type="number"
                            value={selectedField.maxFileSize ? selectedField.maxFileSize / (1024 * 1024) : ''} 
                            onChange={e => updateField(selectedField.id, 'maxFileSize', Number(e.target.value) * 1024 * 1024)} 
                            placeholder="e.g. 5" 
                          />
                        </div>
                      </>
                    )}

                    {/* Number & Rating Specific Settings */}
                    {(selectedField.type === 'number' || selectedField.type === 'rating') && (
                      <div className="row" style={{ gap: '12px' }}>
                        <div className="setting-group" style={{ flex: 1 }}>
                          <label>Min Value</label>
                          <input type="number" value={selectedField.min || ''} onChange={e => updateField(selectedField.id, 'min', e.target.value)} />
                        </div>
                        <div className="setting-group" style={{ flex: 1 }}>
                          <label>Max Value</label>
                          <input type="number" value={selectedField.max || ''} onChange={e => updateField(selectedField.id, 'max', e.target.value)} />
                        </div>
                      </div>
                    )}

                    <div className="setting-group row" style={{ gap: '8px' }}>
                      <label style={{ margin: 0 }}>Required</label>
                      <input type="checkbox" checked={selectedField.required} onChange={e => updateField(selectedField.id, 'required', e.target.checked)} />
                    </div>
                  </>
                )}

                {(selectedField.type === 'dropdown' || selectedField.type === 'multipleChoice' || selectedField.type === 'checkboxes') && (
                  <div className="setting-group">
                    <label>Options (one per line)</label>
                    <textarea 
                      value={(selectedField.options || []).join('\n')} 
                      onChange={e => updateField(selectedField.id, 'options', e.target.value.split('\n'))} 
                    />
                  </div>
                )}

                <div className="setting-group">
                  <label>Custom Error Message</label>
                  <input value={selectedField.errorMessage || ''} onChange={e => updateField(selectedField.id, 'errorMessage', e.target.value)} placeholder="e.g. This field is mandatory" />
                </div>
              </>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}