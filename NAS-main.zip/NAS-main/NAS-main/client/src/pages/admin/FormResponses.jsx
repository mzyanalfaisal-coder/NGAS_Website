import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api, fmtDate, asset } from '../../lib/api';

export default function FormResponses() {
  const { id } = useParams();
  const [form, setForm] = useState(null);
  const [responses, setResponses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([
      api.get(`/forms/${id}`),
      api.get(`/forms/${id}/responses`)
    ])
      .then(([formData, responsesData]) => {
        setForm(formData);
        setResponses(responsesData);
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  const handleDelete = async (responseId) => {
    if (!window.confirm('Are you sure you want to delete this response?')) return;
    try {
      await api.del(`/forms/${id}/responses/${responseId}`);
      setResponses(prev => prev.filter(r => r._id !== responseId));
    } catch (err) {
      alert(err.message);
    }
  };

  const exportCSV = () => {
    if (!form || !responses.length) return alert('No responses to export.');
    
    // Create headers
    const headers = ['Submission ID', 'Date', ...form.fields.map(f => f.label)];
    
    // Create rows
    const rows = responses.map(r => {
      const row = [
        r._id,
        fmtDate(r.submittedAt),
      ];
      
      form.fields.forEach(f => {
        const answer = r.responses.find(res => res.fieldId === f.id);
        if (!answer) return row.push('');
        
        if (f.type === 'file') {
          // If it's a file, give the full URL
          row.push(window.location.origin.includes('localhost') ? `http://localhost:5000${answer.value}` : answer.value);
        } else if (Array.isArray(answer.value)) {
          row.push(answer.value.join(', '));
        } else {
          row.push(answer.value);
        }
      });
      return row;
    });

    // Convert to CSV format
    const csvContent = [headers, ...rows].map(e => e.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
    
    // Download file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${form.title.replace(/\s+/g, '_')}_Responses.csv`;
    link.click();
  };

  if (loading) return <p className="muted state">Loading responses...</p>;
  if (error) return <p className="error state">{error}</p>;

  return (
    <>
      <div className="adm-head">
        <div>
          <div className="row" style={{ gap: '12px', marginBottom: '8px' }}>
            <Link to="/admin/forms" className="link text-sm">← Back to Forms</Link>
          </div>
          <h1>{form.title} - Responses</h1>
          <p className="muted">Total {responses.length} responses received.</p>
        </div>
        <button className="btn btn-primary" onClick={exportCSV} disabled={!responses.length}>
          Export to CSV
        </button>
      </div>

      {responses.length === 0 ? (
        <div className="card pad state" style={{ textAlign: 'center' }}>
          <h3>No responses yet.</h3>
          <p className="muted">Share the public link so students can start submitting the form.</p>
        </div>
      ) : (
        <div style={{ overflowX: 'auto', background: '#fff', border: '1px solid var(--line)', borderRadius: '12px' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.9rem' }}>
            <thead style={{ background: 'var(--bg)', borderBottom: '1px solid var(--line)' }}>
              <tr>
                <th style={{ padding: '16px' }}>Date</th>
                {form.fields.map(f => <th key={f.id} style={{ padding: '16px', minWidth: '150px' }}>{f.label}</th>)}
                <th style={{ padding: '16px' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {responses.map(r => (
                <tr key={r._id} style={{ borderBottom: '1px solid var(--line)' }}>
                  <td style={{ padding: '16px', whiteSpace: 'nowrap' }}>{fmtDate(r.submittedAt)}</td>
                  {form.fields.map(f => {
                    const answer = r.responses.find(res => res.fieldId === f.id);
                    if (!answer) return <td key={f.id} style={{ padding: '16px', color: 'var(--muted)' }}>-</td>;
                    
                    if (f.type === 'file') {
                      return (
                        <td key={f.id} style={{ padding: '16px' }}>
                          <a href={asset(answer.value)} target="_blank" rel="noreferrer" className="link">View File ↗</a>
                        </td>
                      );
                    }

                    if (Array.isArray(answer.value)) {
                      return <td key={f.id} style={{ padding: '16px' }}>{answer.value.join(', ')}</td>;
                    }

                    return <td key={f.id} style={{ padding: '16px' }}>{answer.value}</td>;
                  })}
                  <td style={{ padding: '16px' }}>
                    <button className="chip-btn" onClick={() => handleDelete(r._id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}