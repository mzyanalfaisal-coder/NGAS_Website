import { Link } from 'react-router-dom';
import { useFetch } from '../../lib/hooks';
import { api, fmtDate } from '../../lib/api';
import { useState } from 'react';

export default function Forms() {
  const { data: forms, loading, error, reload } = useFetch('/forms');
  const [msg, setMsg] = useState('');

  const handleCreate = async () => {
    try {
      const newForm = await api.post('/forms', { 
        title: 'Untitled Form', 
        description: 'Event registration form',
        status: 'draft' 
      });
      window.location.href = `/admin/forms/${newForm._id}`; // Builder par le jayega
    } catch (err) {
      setMsg(err.message);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this form? All responses will be lost.')) return;
    try {
      await api.del(`/forms/${id}`);
      reload();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <>
      <div className="adm-head">
        <div>
          <h1>Forms</h1>
          <p className="muted">Manage event registration forms and view responses.</p>
        </div>
        <button className="btn btn-primary" onClick={handleCreate}>+ Create New Form</button>
      </div>

      {msg && <p className="error">{msg}</p>}

      {loading ? <p className="muted state">Loading...</p> : error ? <p className="error state">{error}</p> : (
        <div className="forms-grid">
          {forms?.length === 0 && <p className="muted">No forms found. Create one to get started.</p>}
          {forms?.map((f) => (
            <div key={f._id} className="card pad form-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <h3>{f.title}</h3>
                  <span className={`pill ${f.status === 'published' ? 'upcoming' : 'draft'}`}>{f.status}</span>
                </div>
                {f.status === 'published' && (
                  <a href={`/forms/${f.slug}`} target="_blank" rel="noreferrer" className="link text-sm">View Public ↗</a>
                )}
              </div>
              
              <p className="muted" style={{ fontSize: '0.85rem', marginTop: '8px' }}>
                {f.eventName ? `Event: ${f.eventName} • ` : ''} Created: {fmtDate(f.createdAt)}
              </p>

              <div className="stat-box">
                <b>{f.responseCount || 0}</b> <span>Responses</span>
              </div>

              <div style={{ display: 'flex', gap: '8px', marginTop: '16px', flexWrap: 'wrap' }}>
                <Link className="btn btn-light btn-sm" to={`/admin/forms/${f._id}`}>Edit</Link>
                <Link className="btn btn-light btn-sm" to={`/admin/forms/${f._id}/responses`}>Responses</Link>
                <button className="btn btn-light btn-sm" onClick={() => handleDelete(f._id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}