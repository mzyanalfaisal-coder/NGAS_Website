import { useEffect, useRef, useState } from 'react';
import { api, asset } from '../../lib/api';

export default function GalleryAdmin() {
  const [events, setEvents] = useState([]);
  const [event, setEvent] = useState('');
  const [type, setType] = useState('all');
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [sel, setSel] = useState(new Set());
  const [queue, setQueue] = useState([]);
  const [moveTo, setMoveTo] = useState('');
  const [err, setErr] = useState('');
  const input = useRef();

  useEffect(() => { api.get('/events?all=1').then((e) => { setEvents(e); if (e[0]) setEvent(e[0]._id); }).catch((x) => setErr(x.message)); }, []);
  const load = () => event && api.get(`/media?event=${event}&limit=60${type !== 'all' ? `&type=${type}` : ''}`).then((r) => { setItems(r.items); setTotal(r.total); setSel(new Set()); });
  useEffect(() => { load(); }, [event, type]); // eslint-disable-line

  const upload = async (files) => {
    if (!event) return setErr('Create an event first, then choose it above.');
    setErr('');
    const list = [...files];
    for (const f of list) {
      const id = Math.random();
      setQueue((q) => [...q, { id, name: f.name, state: 'uploading' }]);
      const fd = new FormData(); fd.append('event', event); fd.append('files', f);
      try { await api.postForm('/media', fd); setQueue((q) => q.map((x) => (x.id === id ? { ...x, state: 'done' } : x))); }
      catch (e) { setQueue((q) => q.map((x) => (x.id === id ? { ...x, state: 'error', msg: e.message } : x))); }
    }
    load(); setTimeout(() => setQueue((q) => q.filter((x) => x.state === 'error')), 2500);
  };
  const toggle = (id) => setSel((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const del = async () => { if (confirm(`Delete ${sel.size} item(s)?`)) { await api.post('/media/bulk-delete', { ids: [...sel] }); load(); } };
  const move = async () => { if (moveTo) { await api.post('/media/bulk-move', { ids: [...sel], event: moveTo }); setMoveTo(''); load(); } };

  return (
    <>
      <div className="adm-head"><div><h1>Gallery</h1><p className="muted">Upload photos and videos and assign them to an event.</p></div>
        <button className="btn btn-primary" onClick={() => input.current.click()}>Upload files</button></div>
      <div className="toolbar">
        <label className="field inline"><span>Event</span><select value={event} onChange={(e) => setEvent(e.target.value)}>
          {events.map((e) => <option key={e._id} value={e._id}>{e.title}</option>)}</select></label>
        <div className="seg">{['all', 'photo', 'video'].map((t) => <button key={t} className={type === t ? 'on' : ''} onClick={() => setType(t)}>{t === 'all' ? 'All' : t === 'photo' ? 'Photos' : 'Videos'}</button>)}</div>
        <span className="muted">{total} items</span>
      </div>
      {err && <p className="error">{err}</p>}
      <div className="dropzone" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); upload(e.dataTransfer.files); }}>
        <b>Drag &amp; drop photos and videos here</b>
        <span className="muted">or browse files · JPG, PNG, WEBP · MP4, MOV, WEBM up to 200 MB</span>
        <button className="btn btn-light btn-sm" onClick={() => input.current.click()}>Browse files</button>
        <input ref={input} type="file" multiple hidden accept="image/*,video/*" onChange={(e) => { upload(e.target.files); e.target.value = ''; }} />
      </div>
      {queue.length > 0 && <div className="card pad queue">{queue.map((q) => <div key={q.id}><span>{q.name}</span><b className={q.state}>{q.state === 'uploading' ? 'Uploading…' : q.state === 'done' ? 'Done' : q.msg}</b></div>)}</div>}
      {sel.size > 0 && (
        <div className="bulk"><b>{sel.size} selected</b>
          <span className="row gap-s"><select value={moveTo} onChange={(e) => setMoveTo(e.target.value)}><option value="">Move to event…</option>{events.filter((e) => e._id !== event).map((e) => <option key={e._id} value={e._id}>{e.title}</option>)}</select>
            <button onClick={move} disabled={!moveTo}>Move</button><button onClick={del} className="danger">Delete</button></span></div>)}
      <div className="media-grid">
        {items.map((m) => (
          <div key={m._id} className={`mi ${sel.has(m._id) ? 'sel' : ''}`} onClick={() => toggle(m._id)}>
            {m.type === 'video' ? <video src={asset(m.url)} preload="metadata" muted /> : <img src={asset(m.url)} alt="" loading="lazy" />}
            <span className="ck">{sel.has(m._id) ? '✓' : ''}</span>{m.type === 'video' && <span className="dur">▶ video</span>}
          </div>))}
        {!items.length && <p className="muted">No media for this event yet.</p>}
      </div>
    </>
  );
}
