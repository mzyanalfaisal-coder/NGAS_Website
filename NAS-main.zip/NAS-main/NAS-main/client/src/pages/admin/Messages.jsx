import { useFetch } from '../../lib/hooks';
import { api, fmtDate } from '../../lib/api';

export default function Messages() {
  const { data, error, reload } = useFetch('/content/messages');
  const toggle = async (m) => { await api.patch(`/content/messages/${m._id}`, { read: !m.read }); reload(); };
  const del = async (m) => { if (confirm('Delete this message?')) { await api.del(`/content/messages/${m._id}`); reload(); } };
  return (
    <>
      <div className="adm-head"><div><h1>Messages</h1><p className="muted">Submissions from the Contact page.</p></div></div>
      {error && <p className="error">{error}</p>}
      <div className="stack">
        {(data || []).map((m) => (
          <div key={m._id} className={`card pad msg ${m.read ? '' : 'unread'}`}>
            <div className="sec-head"><div><b>{m.name}</b> <a className="link" href={`mailto:${m.email}`}>{m.email}</a></div><small className="muted">{fmtDate(m.createdAt)}</small></div>
            <small className="eyebrow">{m.subject}</small><p>{m.message}</p>
            <div className="row gap-s"><button className="link" onClick={() => toggle(m)}>{m.read ? 'Mark unread' : 'Mark read'}</button><button className="link danger" onClick={() => del(m)}>Delete</button></div>
          </div>))}
        {data && !data.length && <p className="muted">No messages yet.</p>}
      </div>
    </>
  );
}
