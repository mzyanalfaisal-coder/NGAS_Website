import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, asset } from '../../lib/api';
import { logoStyle } from '../../components/ui.jsx';

const toInput = (v, type) => (type === 'date' ? (v ? new Date(v).toISOString().slice(0, 10) : '') : v ?? '');

// type 'focus': click the image to pick a point, slider sets zoom; `of` is the file field it applies to
function FocusField({ f, v, setV, src }) {
  if (!src) return null;
  const [fx, fy] = (v[f.name] || '50% 50%').split(' ');
  const pick = (e) => {
    const b = e.currentTarget.getBoundingClientRect();
    const pct = (n) => `${Math.round(Math.min(100, Math.max(0, n * 100)))}%`;
    setV({ ...v, [f.name]: `${pct((e.clientX - b.left) / b.width)} ${pct((e.clientY - b.top) / b.height)}` });
  };
  return (
    <div className="field"><span>{f.label}</span>
      <div className="focus-pick" onClick={pick}><img src={src} alt="" /><i style={{ left: fx, top: fy }} /></div>
      <div className="row gap-s"><small className="muted">Zoom {Number(v[f.zoom]).toFixed(1)}×</small>
        <input type="range" min="1" max="4" step="0.1" value={v[f.zoom]} onChange={(e) => setV({ ...v, [f.zoom]: e.target.value })} />
        <button type="button" className="link" onClick={() => setV({ ...v, [f.name]: '50% 50%', [f.zoom]: 1 })}>Reset</button></div>
      <span>Preview</span>
      <div className="sponsor focus-box"><img src={src} alt="" style={logoStyle(v[f.name], v[f.zoom])} /></div>
    </div>
  );
}

function Form({ title, fields, doc, onClose, onSaved, endpoint }) {
  const [v, setV] = useState(() => ({
    ...Object.fromEntries(fields.filter((f) => f.zoom).map((f) => [f.zoom, doc?.[f.zoom] ?? 1])),
    ...Object.fromEntries(fields.map((f) => [f.name, f.type === 'checkbox' ? (doc ? !!doc[f.name] : !!f.default) : toInput(doc?.[f.name] ?? f.default, f.type)])),
  }));
  const [files, setFiles] = useState({});
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr('');
    const fd = new FormData();
    fields.forEach((f) => {
      if (f.type === 'file') { if (files[f.name]) fd.append(f.name, files[f.name]); }
      else { fd.append(f.name, v[f.name]); if (f.zoom) fd.append(f.zoom, v[f.zoom]); }
    });
    try {
      doc ? await api.putForm(`${endpoint}/${doc._id}`, fd) : await api.postForm(endpoint, fd);
      onSaved();
    } catch (x) { setErr(x.message); setBusy(false); }
  };
  return (
    <div className="drawer-bg" onClick={onClose}>
      <form className="drawer" onClick={(e) => e.stopPropagation()} onSubmit={submit}>
        <div className="adm-head"><h2>{doc ? 'Edit' : 'Add'} {title}</h2><button type="button" className="x" onClick={onClose}>✕</button></div>
        {fields.map((f) => f.type === 'focus' ? <FocusField key={f.name} f={f} v={v} setV={setV} src={files[f.of] ? URL.createObjectURL(files[f.of]) : doc?.[f.of] && asset(doc[f.of])} /> : (
          <label key={f.name} className={`field ${f.type === 'checkbox' ? 'check' : ''}`}>
            <span>{f.label}{f.required && ' *'}</span>
            {f.type === 'textarea' ? <textarea rows={4} value={v[f.name]} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />
              : f.type === 'select' ? <select value={v[f.name]} onChange={(e) => setV({ ...v, [f.name]: e.target.value })}>{f.options.map((o) => <option key={o} value={o}>{o}</option>)}</select>
              : f.type === 'checkbox' ? <input type="checkbox" checked={v[f.name]} onChange={(e) => setV({ ...v, [f.name]: e.target.checked })} />
              : f.type === 'file' ? <>
                  {(files[f.name] ? URL.createObjectURL(files[f.name]) : doc?.[f.name] && asset(doc[f.name])) && <img className="prev" src={files[f.name] ? URL.createObjectURL(files[f.name]) : asset(doc[f.name])} alt="" />}
                  <input type="file" accept="image/*" onChange={(e) => setFiles({ ...files, [f.name]: e.target.files[0] })} /></>
              : <input type={f.type || 'text'} required={f.required} value={v[f.name]} placeholder={f.placeholder} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />}
            {f.help && <small className="muted">{f.help}</small>}
          </label>
        ))}
        {err && <p className="error">{err}</p>}
        <div className="row gap-s"><button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button><button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button></div>
      </form>
    </div>
  );
}

export default function ResourceManager({ title, singular, sub, endpoint, fields, columns, filterField, filterOptions }) {
  const [rows, setRows] = useState(null);
  const [err, setErr] = useState('');
  const [editing, setEditing] = useState(undefined); // undefined closed, null new, doc edit
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('All');
  const [params, setParams] = useSearchParams();
  const load = () => api.get(`${endpoint}?all=1`).then(setRows).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []); // eslint-disable-line
  useEffect(() => { if (params.get('new')) { setEditing(null); setParams({}); } }, []); // eslint-disable-line
  const remove = async (r) => {
    if (!confirm(`Delete “${r.title || r.name}”? This can’t be undone.`)) return;
    try { await api.del(`${endpoint}/${r._id}`); load(); } catch (e) { alert(e.message); }
  };
  const shown = (rows || []).filter((r) => (filter === 'All' || r[filterField] === filter.toLowerCase()) &&
    JSON.stringify(r).toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <div className="adm-head"><div><h1>{title}</h1><p className="muted">{sub}</p></div><button className="btn btn-primary" onClick={() => setEditing(null)}>+ Add {singular}</button></div>
      <div className="toolbar">
        {filterField && <div className="seg">{['All', ...filterOptions].map((o) => <button key={o} className={filter === o ? 'on' : ''} onClick={() => setFilter(o)}>{o}</button>)}</div>}
        <input className="search" placeholder={`Search ${title.toLowerCase()}…`} value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {err && <p className="error">{err}</p>}
      <div className="card tbl-wrap"><table className="tbl">
        <thead><tr>{columns.map((c) => <th key={c.label}>{c.label}</th>)}<th /></tr></thead>
        <tbody>
          {shown.map((r) => <tr key={r._id}>{columns.map((c) => <td key={c.label}>{c.render ? c.render(r) : r[c.key]}</td>)}
            <td className="acts"><button className="link" onClick={() => setEditing(r)}>Edit</button><button className="link danger" onClick={() => remove(r)}>Delete</button></td></tr>)}
          {rows && !shown.length && <tr><td colSpan={columns.length + 1} className="muted">Nothing here yet.</td></tr>}
        </tbody></table></div>
      {editing !== undefined && <Form title={singular} fields={fields} doc={editing} endpoint={endpoint} onClose={() => setEditing(undefined)} onSaved={() => { setEditing(undefined); load(); }} />}
    </>
  );
}
