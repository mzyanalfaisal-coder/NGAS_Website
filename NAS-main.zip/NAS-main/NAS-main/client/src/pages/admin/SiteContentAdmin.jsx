import { useEffect, useState } from 'react';
import { api, asset } from '../../lib/api';

export default function SiteContentAdmin() {
  const [c, setC] = useState(null);
  const [files, setFiles] = useState({});
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [pw, setPw] = useState({ current: '', next: '' });
  const [pwMsg, setPwMsg] = useState('');
  useEffect(() => { api.get('/content').then(setC).catch((e) => setMsg(e.message)); }, []);
  if (!c) return <p className="muted">{msg || 'Loading…'}</p>;
  const set = (k, v) => setC({ ...c, [k]: v });
  const setContact = (k, v) => setC({ ...c, contact: { ...c.contact, [k]: v } });
  const list = (key, i, k, v) => setC({ ...c, [key]: c[key].map((x, j) => (j === i ? { ...x, [k]: v } : x)) });
  const save = async () => {
    setBusy(true); setMsg('');
    const fd = new FormData();
    const { heroImage, aboutImage, _id, __v, createdAt, updatedAt, key, ...data } = c;
    fd.append('data', JSON.stringify(data));
    Object.entries(files).forEach(([k, f]) => fd.append(k, f));
    try { setC(await api.putForm('/content', fd)); setFiles({}); setMsg('Saved ✓'); } catch (e) { setMsg(e.message); }
    setBusy(false);
  };
  const changePw = async (e) => {
    e.preventDefault();
    try { await api.post('/auth/change-password', pw); setPwMsg('Password updated ✓'); setPw({ current: '', next: '' }); } catch (x) { setPwMsg(x.message); }
  };
  const T = (label, k, rows) => <label className="field"><span>{label}</span>{rows ? <textarea rows={rows} value={c[k] || ''} onChange={(e) => set(k, e.target.value)} /> : <input value={c[k] || ''} onChange={(e) => set(k, e.target.value)} />}</label>;
  const img = (k, label) => <label className="field"><span>{label}</span>
    {(files[k] || c[k]) && <img className="prev" src={files[k] ? URL.createObjectURL(files[k]) : asset(c[k])} alt="" />}
    <input type="file" accept="image/*" onChange={(e) => setFiles({ ...files, [k]: e.target.files[0] })} /></label>;
  // Click the preview to pick the part of the hero image that stays in view
  const heroSrc = files.heroImage ? URL.createObjectURL(files.heroImage) : c.heroImage && asset(c.heroImage);
  const [fx, fy] = (c.heroFocus || '50% 50%').split(' ');
  const pickFocus = (e) => {
    const b = e.currentTarget.getBoundingClientRect();
    const pct = (v) => `${Math.round(Math.min(100, Math.max(0, v * 100)))}%`;
    set('heroFocus', `${pct((e.clientX - b.left) / b.width)} ${pct((e.clientY - b.top) / b.height)}`);
  };
  const heroPicker = heroSrc && <div className="field"><span>Image focus — click the part of the photo that should stay visible</span>
    <div className="focus-pick" onClick={pickFocus}><img src={heroSrc} alt="" /><i style={{ left: fx, top: fy }} /></div>
    <div className="row gap-s"><small className="muted">Position: {c.heroFocus || '50% 50%'}</small>
      <button type="button" className="link" onClick={() => set('heroFocus', '50% 50%')}>Reset to center</button></div>
    <span>Homepage preview</span>
    <div className="focus-prev" style={{ backgroundImage: `url(${heroSrc})`, backgroundPosition: c.heroFocus || 'center' }} /></div>;
  return (
    <>
      <div className="adm-head"><div><h1>Site Content</h1><p className="muted">Edit text and images on Home, About and Contact.</p></div>
        <div className="row gap-s">{msg && <span className={msg.includes('✓') ? 'ok' : 'error'}>{msg}</span>}<button className="btn btn-primary" onClick={save} disabled={busy}>{busy ? 'Saving…' : 'Save all'}</button></div></div>
      <div className="card pad form"><h3>Home · Hero</h3>{T('Headline', 'heroHeadline')}{T('Sub-headline', 'heroSub', 3)}{img('heroImage', 'Background image')}{heroPicker}
        <h4>Stats</h4>{(c.stats || []).map((s, i) => <div key={i} className="two"><input placeholder="40+" value={s.value || ''} onChange={(e) => list('stats', i, 'value', e.target.value)} /><input placeholder="Expeditions" value={s.label || ''} onChange={(e) => list('stats', i, 'label', e.target.value)} /></div>)}</div>
      <div className="card pad form"><h3>About Us</h3>{T('Heading', 'aboutHeading')}{T('About NGAS', 'aboutText', 5)}{img('aboutImage', 'Photo')}{T('Vision', 'vision', 3)}{T('Mission', 'mission', 3)}</div>
      <div className="card pad form"><h3>FAQs</h3>
        {(c.faqs || []).map((f, i) => <div key={i} className="faq-edit"><input placeholder="Question" value={f.q || ''} onChange={(e) => list('faqs', i, 'q', e.target.value)} />
          <textarea rows={2} placeholder="Answer" value={f.a || ''} onChange={(e) => list('faqs', i, 'a', e.target.value)} />
          <button className="link danger" onClick={() => set('faqs', c.faqs.filter((_, j) => j !== i))}>Remove</button></div>)}
        <button className="btn btn-light btn-sm" onClick={() => set('faqs', [...(c.faqs || []), { q: '', a: '' }])}>+ Add FAQ</button></div>
      <div className="card pad form"><h3>Contact details</h3>
        <div className="two">{[['email', 'Email'], ['phone', 'Phone'], ['address', 'Address'], ['hours', 'Office hours'], ['instagram', 'Instagram URL'], ['linkedin', 'LinkedIn URL'], ['facebook', 'Facebook URL'], ['youtube', 'YouTube URL']].map(([k, l]) =>
          <label key={k} className="field"><span>{l}</span><input value={c.contact?.[k] || ''} onChange={(e) => setContact(k, e.target.value)} /></label>)}</div></div>
      <form className="card pad form" onSubmit={changePw}><h3>Change admin password</h3>
        <div className="two"><label className="field"><span>Current password</span><input type="password" required value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} /></label>
          <label className="field"><span>New password (min 8)</span><input type="password" required minLength={8} value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} /></label></div>
        {pwMsg && <p className={pwMsg.includes('✓') ? 'ok' : 'error'}>{pwMsg}</p>}<button className="btn btn-ghost btn-sm">Update password</button></form>
    </>
  );
}
