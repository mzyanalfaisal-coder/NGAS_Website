import { useState } from 'react';
import { useFetch } from '../lib/hooks';
import { Img, PageHead, Section } from '../components/ui.jsx';

export default function About() {
  const { data: c } = useFetch('/content');
  const [open, setOpen] = useState(0);
  return (
    <>
      <PageHead eyebrow="ABOUT US" title="About NAS" sub="Ned Adventure Society is a student community built around exploration, teamwork and the outdoors." />
      <Section>
        <div className="about-split">
          <div><span className="eyebrow">WHO WE ARE</span><h2>{c?.aboutHeading}</h2>
            {(c?.aboutText || '').split('\n').filter(Boolean).map((p, i) => <p key={i} className="muted">{p}</p>)}</div>
          <Img src={c?.aboutImage} className="about-img" alt="NAS members on a trek" />
        </div>
      </Section>
      <section className="container vm">
        <div className="vm-card"><span className="vm-ic">◉</span><h3>Our Vision</h3><p>{c?.vision}</p></div>
        <div className="vm-card dark"><span className="vm-ic">◎</span><h3>Our Mission</h3><p>{c?.mission}</p></div>
      </section>
      <Section eyebrow="Good to know" title="Frequently Asked Questions" className="white">
        <div className="faq">
          {(c?.faqs || []).map((f, i) => (
            <div key={i} className={`faq-item ${open === i ? 'open' : ''}`}>
              <button onClick={() => setOpen(open === i ? -1 : i)} aria-expanded={open === i}><span>{f.q}</span><b>{open === i ? '–' : '+'}</b></button>
              {open === i && <p>{f.a}</p>}
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}
