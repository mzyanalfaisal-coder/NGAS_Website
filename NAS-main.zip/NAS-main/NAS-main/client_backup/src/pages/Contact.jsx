import { useState } from 'react';
import { api } from '../lib/api';
import { useFetch } from '../lib/hooks';
import { PageHead } from '../components/ui.jsx';

export default function Contact() {
  const { data: c } = useFetch('/content');
  const ct = c?.contact || {};
  const [f, setF] = useState({ name: '', email: '', subject: 'General question', message: '' });
  const [status, setStatus] = useState({ type: '', msg: '' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setStatus({});
    try { await api.post('/content/messages', f); setStatus({ type: 'ok', msg: 'Thanks! Your message has been sent — we’ll get back to you soon.' }); setF({ ...f, name: '', email: '', message: '' }); }
    catch (err) { setStatus({ type: 'err', msg: err.message }); }
    setBusy(false);
  };
  return (
    <>
      <PageHead eyebrow="CONTACT US" title="Get in touch" sub="Questions, sponsorship ideas or want to join? Drop us a message." />
      <section className="container contact-split">
        <form className="card form" onSubmit={submit}>
          <h3>Send us a message</h3>
          <div className="two">
            <label className="field"><span>Full name</span><input required value={f.name} onChange={set('name')} placeholder="Your name" /></label>
            <label className="field"><span>Email</span><input required type="email" value={f.email} onChange={set('email')} placeholder="you@neduet.edu.pk" /></label>
          </div>
          <label className="field"><span>Subject</span>
            <select value={f.subject} onChange={set('subject')}>{['General question', 'Joining NAS', 'Sponsorship', 'Event feedback', 'Other'].map((s) => <option key={s}>{s}</option>)}</select></label>
          <label className="field"><span>Message</span><textarea required rows={6} value={f.message} onChange={set('message')} placeholder="Write your message…" /></label>
          {status.msg && <p className={status.type === 'ok' ? 'ok' : 'error'}>{status.msg}</p>}
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Sending…' : 'Send Message'}</button>
        </form>
        <div className="stack">
          {[['Email', ct.email], ['Phone', ct.phone], ['Address', ct.address], ['Hours', ct.hours]].filter(([, v]) => v).map(([k, v]) => (
            <div key={k} className="card info"><span className="info-ic">{k}</span><div><small>{k.toUpperCase()}</small><b>{v}</b></div></div>
          ))}
          <div className="row gap-s wrap">{[['instagram', 'Instagram'], ['linkedin', 'LinkedIn'], ['facebook', 'Facebook'], ['youtube', 'YouTube']].map(([k, l]) => ct[k] ? <a key={k} className="chip link-chip" href={ct[k]} target="_blank" rel="noreferrer">{l}</a> : null)}</div>
        </div>
      </section>
    </>
  );
}
