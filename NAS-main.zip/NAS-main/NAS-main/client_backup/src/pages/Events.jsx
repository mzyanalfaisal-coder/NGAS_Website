import { useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useFetch } from '../lib/hooks';
import { dateRange, daysLabel } from '../lib/api';
import { Img, PageHead, Section, State } from '../components/ui.jsx';

function Card({ e, open, onToggle, past, counts }) {
  const ref = useRef();
  useEffect(() => { if (open) ref.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, [open]);
  const n = counts?.[e._id] || { photo: 0, video: 0 };
  const canRegister = e.registrationLink && e.registrationOpen;
  return (
    <article ref={ref} className={`card ev-card ${open ? 'open' : ''}`}>
      <button className="ev-hit" onClick={onToggle} aria-expanded={open}>
        <Img src={e.coverImage} alt={e.title} />
        <div className="ev-body">
          <div className="row gap-s">
            <span className="chip">{dateRange(e.date, e.duration, { year: past }).toUpperCase()}</span>
            {past && <span className="chip chip-line">COMPLETED</span>}
            {open && !past && (canRegister ? <span className="chip chip-solid">REGISTRATION OPEN</span> : <span className="chip chip-line">REGISTRATION CLOSED</span>)}
          </div>
          <h3>{e.title}</h3>
          <p className="muted">{[e.venue, daysLabel(e.duration)].filter(Boolean).join(' · ')}</p>
          {!open && <span className="link">{past ? 'Click to select' : 'Click to expand ⌄'}</span>}
        </div>
      </button>
      <div className="ev-collapse"><div className="ev-clip" aria-hidden={!open}>
        <div className="ev-more">
          {e.description && <p>{e.description}</p>}
          <dl className="details">
            {[['DATE', `${dateRange(e.date, e.duration)}${e.time ? ' · ' + e.time : ''}`], ['VENUE', e.venue], ['FEE', e.fee], ['SEATS', e.seats], ['INCLUDED', e.included]]
              .filter(([, v]) => v).map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v}</dd></div>)}
          </dl>
          {past ? (
            <div className="row gap-s">
              <Link className="btn btn-primary" to={`/gallery?event=${e._id}`}>View Gallery →</Link>
              <span className="muted">{n.photo} photos · {n.video} videos</span>
            </div>
          ) : (
            <div className="row gap-s">
              {canRegister
                ? <a className="btn btn-primary" href={e.registrationLink} target="_blank" rel="noreferrer">Register Now ↗</a>
                : <button className="btn btn-primary" disabled>{e.registrationLink ? 'Registration closed' : 'Registration opening soon'}</button>}
              <button className="btn btn-ghost" onClick={onToggle}>Collapse</button>
            </div>
          )}
        </div>
      </div></div>
    </article>
  );
}

export default function Events() {
  const { data, loading, error } = useFetch('/events');
  const { data: counts } = useFetch('/media/counts');
  const [params] = useSearchParams();
  const [openId, setOpenId] = useState(params.get('open'));
  const [tab, setTab] = useState('upcoming');
  const upcoming = (data || []).filter((e) => e.status === 'upcoming');
  const past = (data || []).filter((e) => e.status === 'past').sort((a, b) => new Date(b.date) - new Date(a.date));
  const toggle = (id) => setOpenId((cur) => (cur === id ? null : id));
  const go = (t) => { setTab(t); document.getElementById(t)?.scrollIntoView({ behavior: 'smooth' }); };
  return (
    <>
      <PageHead eyebrow="NAS EVENTS" title="Events" sub="Find your next adventure — or relive the ones you missed.">
        <div className="seg">
          <button className={tab === 'upcoming' ? 'on' : ''} onClick={() => go('upcoming')}>Upcoming · {upcoming.length}</button>
          <button className={tab === 'past' ? 'on' : ''} onClick={() => go('past')}>Past · {past.length}</button>
        </div>
      </PageHead>
      <State loading={loading} error={error}>
        <div id="upcoming"><Section eyebrow="Coming up" title="Upcoming Events">
          {upcoming.length ? <div className="grid-3">{upcoming.map((e) => <Card key={e._id} e={e} open={openId === e._id} onToggle={() => toggle(e._id)} />)}</div>
            : <p className="muted">No upcoming events right now.</p>}
        </Section></div>
        <div id="past"><Section eyebrow="Memories" title="Past Events" className="white">
          {past.length ? <div className="grid-3">{past.map((e) => <Card key={e._id} past e={e} counts={counts} open={openId === e._id} onToggle={() => toggle(e._id)} />)}</div>
            : <p className="muted">No past events yet.</p>}
        </Section></div>
      </State>
    </>
  );
}
