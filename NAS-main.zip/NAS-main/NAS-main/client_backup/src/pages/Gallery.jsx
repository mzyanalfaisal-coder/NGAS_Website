import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, asset } from '../lib/api';
import { useFetch } from '../lib/hooks';
import { PageHead } from '../components/ui.jsx';

export default function Gallery() {
  const [params, setParams] = useSearchParams();
  const event = params.get('event') || 'all';
  const [type, setType] = useState('all');
  const [page, setPage] = useState(1);
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [light, setLight] = useState(null);
  const { data: events } = useFetch('/events');
  const opts = (events || []).filter((e) => e.status === 'past' || e.status === 'upcoming');

  useEffect(() => { setPage(1); }, [event, type]);
  useEffect(() => {
    setLoading(true);
    const q = new URLSearchParams({ page, limit: 24 });
    if (event !== 'all') q.set('event', event);
    if (type !== 'all') q.set('type', type);
    api.get(`/media?${q}`).then((r) => {
      setItems((prev) => (page === 1 ? r.items : [...prev, ...r.items])); setTotal(r.total); setPages(r.pages); setError('');
    }).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, [event, type, page]);

  useEffect(() => {
    const k = (e) => e.key === 'Escape' && setLight(null);
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, []);

  const selected = opts.find((e) => e._id === event);
  return (
    <>
      <PageHead eyebrow="NAS GALLERY" title="Gallery" sub="Photos and videos from every adventure, straight from the NAS archive." />
      <section className="container filter-bar">
        <label className="field"><span className="eyebrow">EVENT</span>
          <select value={event} onChange={(e) => { const v = e.target.value; setParams(v === 'all' ? {} : { event: v }); }}>
            <option value="all">All events</option>
            {opts.map((e) => <option key={e._id} value={e._id}>{e.title}</option>)}
          </select>
        </label>
        <div className="row gap-s">{[['all', 'All'], ['photo', 'Photos'], ['video', 'Videos']].map(([v, l]) =>
          <button key={v} className={`chip-btn ${type === v ? 'on' : ''}`} onClick={() => setType(v)}>{l}</button>)}</div>
        <span className="muted">Showing {total} item{total === 1 ? '' : 's'} · {selected ? selected.title : 'All events'}</span>
      </section>
      <section className="container gallery-wrap">
        {error && <p className="error">{error}</p>}
        {!loading && !items.length && !error && <p className="muted state">Nothing here yet — photos and videos will appear once the admin uploads them.</p>}
        <div className="masonry">
          {items.map((m) => (
            <button key={m._id} className="tile" onClick={() => setLight(m)}>
              {m.type === 'video'
                ? <><video src={asset(m.url)} preload="metadata" muted /><span className="play">▶</span></>
                : <img src={asset(m.url)} alt={m.event?.title || ''} loading="lazy" />}
              {event === 'all' && m.event?.title && <span className="tag">{m.event.title}</span>}
            </button>
          ))}
        </div>
        {loading && <p className="muted state">Loading…</p>}
        {!loading && page < pages && <div className="center"><button className="btn btn-ghost" onClick={() => setPage(page + 1)}>Load more</button></div>}
      </section>
      {light && (
        <div className="lightbox" onClick={() => setLight(null)}>
          <button className="lb-x" aria-label="Close">✕</button>
          <div onClick={(e) => e.stopPropagation()}>
            {light.type === 'video' ? <video src={asset(light.url)} controls autoPlay /> : <img src={asset(light.url)} alt="" />}
            <p>{light.event?.title}</p>
          </div>
        </div>
      )}
    </>
  );
}
