import { useState } from 'react';
import { useFetch } from '../lib/hooks';
import { Img, PageHead, State } from '../components/ui.jsx';

export default function Team() {
  const { data, loading, error } = useFetch('/team');
  const [domain, setDomain] = useState('All');
  const domains = ['All', ...new Set((data || []).map((m) => m.domain).filter(Boolean))];
  const list = (data || []).filter((m) => domain === 'All' || m.domain === domain);
  return (
    <>
      <PageHead eyebrow="OUR TEAM" title="Meet the Team" sub="The students behind every trek, camp and campaign at NAS." />
      <section className="container">
        <div className="row gap-s wrap filter-row">{domains.map((d) => <button key={d} className={`chip-btn ${domain === d ? 'on' : ''}`} onClick={() => setDomain(d)}>{d}</button>)}</div>
        <State loading={loading} error={error} empty={!list.length && 'Team members will appear here soon.'}>
          <div className="grid-4 team-grid">
            {list.map((m) => (
              <article key={m._id} className="card team-card">
                <Img src={m.photo} alt={m.name} />
                <div><h3>{m.name}</h3><p className="muted">{m.designation}</p>
                  {m.domain && <span className="chip small">{m.domain.toUpperCase()}</span>}
                  {m.linkedin && <a className="li" href={m.linkedin} target="_blank" rel="noreferrer"><b>in</b> LinkedIn ↗</a>}</div>
              </article>
            ))}
          </div>
        </State>
      </section>
    </>
  );
}
