import { Link } from 'react-router-dom';
import { useFetch } from '../../lib/hooks';
import { fmtDate } from '../../lib/api';

export default function Dashboard() {
  const ev = useFetch('/events?all=1');
  const media = useFetch('/media?limit=4');
  const team = useFetch('/team');
  const msgs = useFetch('/content/messages');
  const events = ev.data || [];
  const stat = (a, b, c) => <div className="card stat"><small>{a}</small><b>{b}</b><span>{c}</span></div>;
  return (
    <>
      <div className="adm-head"><div><h1>Dashboard</h1><p className="muted">Welcome back — here’s what’s happening at NAS.</p></div><Link className="btn btn-primary" to="/admin/events?new=1">+ New Event</Link></div>
      <div className="grid-4">
        {stat('Upcoming events', events.filter((e) => e.status === 'upcoming').length, 'published')}
        {stat('Past events', events.filter((e) => e.status === 'past').length, 'archive')}
        {stat('Gallery items', media.data?.total ?? '–', 'photos & videos')}
        {stat('Team members', team.data?.length ?? '–', `${(msgs.data || []).filter((m) => !m.read).length} unread messages`)}
      </div>
      <div className="dash-split">
        <div className="card pad"><div className="sec-head"><h3>Recent events</h3><Link className="link" to="/admin/events">View all →</Link></div>
          <table className="tbl"><tbody>
            {events.slice(0, 6).map((e) => <tr key={e._id}><td><b>{e.title}</b></td><td>{fmtDate(e.date)}</td><td><span className={`pill ${e.status}`}>{e.status}</span></td></tr>)}
            {!events.length && <tr><td className="muted">No events yet.</td></tr>}
          </tbody></table></div>
        <div className="card pad"><h3>Quick actions</h3>
          <div className="stack">{[['/admin/gallery', 'Upload photos & videos'], ['/admin/announcements', 'Post an announcement'], ['/admin/team', 'Add a team member'], ['/admin/sponsors', 'Add a sponsor logo']].map(([to, l]) =>
            <Link key={to} to={to} className="qa">{l}<span>→</span></Link>)}</div></div>
      </div>
    </>
  );
}
