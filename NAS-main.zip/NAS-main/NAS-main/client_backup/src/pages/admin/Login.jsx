import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { api, getToken, setToken } from '../../lib/api';

export default function Login() {
  const nav = useNavigate();
  const [f, setF] = useState({ email: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  if (getToken()) return <Navigate to="/admin" replace />;
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr('');
    try { const r = await api.post('/auth/login', f); setToken(r.token); nav('/admin'); }
    catch (x) { setErr(x.message); setBusy(false); }
  };
  return (
    <div className="login">
      <div className="login-brand">
        <div className="logo dark"><img className="logo-img" src="/logo.png" alt="NAS logo" /><span><b>NAS</b><small>Admin Portal</small></span></div>
        <div><h1>Manage everything NAS, in one place.</h1><p>Update events, announcements, gallery, team and sponsors — no developer needed.</p></div>
        <small>© {new Date().getFullYear()} Ned Adventure Society</small>
      </div>
      <div className="login-form">
        <form className="card form" onSubmit={submit}>
          <h2>Admin sign in</h2><p className="muted">Use your NAS admin account to continue.</p>
          <label className="field"><span>Email</span><input type="email" required autoComplete="username" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></label>
          <label className="field"><span>Password</span><input type="password" required autoComplete="current-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></label>
          {err && <p className="error">{err}</p>}
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        </form>
      </div>
    </div>
  );
}
