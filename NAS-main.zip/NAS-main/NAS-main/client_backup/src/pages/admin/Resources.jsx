import ResourceManager from './ResourceManager.jsx';
import { asset, dateRange, fmtDate } from '../../lib/api';

const thumb = (k, round) => (r) => r[k] ? <img className={`thumb ${round ? 'round' : ''}`} src={asset(r[k])} alt="" /> : <span className="thumb ph" />;
const pill = (r) => <span className={`pill ${r.status}`}>{r.status}</span>;

export const EventsAdmin = () => (
  <ResourceManager title="Events" singular="event" sub="Create, edit and publish upcoming and past events." endpoint="/events"
    filterField="status" filterOptions={['Upcoming', 'Past', 'Draft']}
    columns={[{ label: '', render: thumb('coverImage') }, { label: 'Event', key: 'title' }, { label: 'Date', render: (r) => dateRange(r.date, r.duration) }, { label: 'Venue', key: 'venue' },
      { label: 'Status', render: pill }, { label: 'Form link', render: (r) => (r.registrationLink ? <span className="pill linked">Linked</span> : <span className="pill missing">No link</span>) }]}
    fields={[
      { name: 'title', label: 'Title', required: true },
      { name: 'status', label: 'Status', type: 'select', options: ['upcoming', 'past', 'draft'], default: 'upcoming', help: 'Past events show “View Gallery”; drafts are hidden from the website.' },
      { name: 'date', label: 'Start date', type: 'date', required: true },
      { name: 'time', label: 'Time', placeholder: '7:00 AM' },
      { name: 'duration', label: 'Duration (days)', type: 'number', placeholder: '2', help: 'Number of days, counting from the start date. 2 → 17, 18 Oct.' },
      { name: 'venue', label: 'Venue' },
      { name: 'fee', label: 'Fee', placeholder: 'PKR 18,500 / Free for members' },
      { name: 'seats', label: 'Seats', type: 'number' },
      { name: 'description', label: 'Description', type: 'textarea' },
      { name: 'included', label: 'What’s included', placeholder: 'Transport · Stay · Meals · Guide' },
      { name: 'coverImage', label: 'Cover image', type: 'file' },
      { name: 'registrationLink', label: 'Registration link (Google Form)', type: 'url', placeholder: 'https://forms.gle/…', help: '“Register Now” on the website opens this link.' },
      { name: 'registrationOpen', label: 'Registration open', type: 'checkbox', default: true },
      { name: 'showInAnnouncements', label: 'Highlight on Home', type: 'checkbox' },
    ]} />
);

export const TeamAdmin = () => (
  <ResourceManager title="Team" singular="member" sub="Manage NAS members shown on the Team page." endpoint="/team"
    columns={[{ label: '', render: thumb('photo', true) }, { label: 'Member', key: 'name' }, { label: 'Designation', key: 'designation' }, { label: 'Domain', key: 'domain' },
      { label: 'LinkedIn', render: (r) => (r.linkedin ? '✓ linked' : '—') }, { label: 'Order', key: 'order' }]}
    fields={[
      { name: 'name', label: 'Full name', required: true }, { name: 'designation', label: 'Designation', placeholder: 'Head of Media' },
      { name: 'domain', label: 'Domain', placeholder: 'Media, Logistics, Leadership…' }, { name: 'linkedin', label: 'LinkedIn URL', type: 'url' },
      { name: 'photo', label: 'Photo', type: 'file' }, { name: 'order', label: 'Display order', type: 'number', default: 0, help: 'Lower numbers appear first.' },
    ]} />
);

export const SponsorsAdmin = () => (
  <ResourceManager title="Sponsors" singular="sponsor" sub="Logos shown in the running slider on the Home page." endpoint="/sponsors"
    columns={[{ label: 'Logo', render: thumb('logo') }, { label: 'Name', key: 'name' }, { label: 'Note', key: 'note' }, { label: 'Order', key: 'order' }]}
    fields={[
      { name: 'name', label: 'Sponsor name', required: true }, { name: 'logo', label: 'Logo (PNG/SVG works best)', type: 'file' },
      { name: 'logoFocus', zoom: 'logoZoom', of: 'logo', label: 'Logo area — click the part to zoom into, then set the zoom', type: 'focus', default: '50% 50%' },
      { name: 'website', label: 'Website', type: 'url' }, { name: 'note', label: 'Note', placeholder: 'Sponsored: Winter Trek 2025' },
      { name: 'order', label: 'Slider order', type: 'number', default: 0 },
    ]} />
);

export const AnnouncementsAdmin = () => (
  <ResourceManager title="Announcements" singular="announcement" sub="Short notices shown beside Upcoming Events on Home." endpoint="/announcements"
    columns={[{ label: 'Headline', key: 'title' }, { label: 'Date', render: (r) => fmtDate(r.date) }, { label: 'Pinned', render: (r) => (r.pinned ? '📌' : '') },
      { label: 'Status', render: (r) => <span className={`pill ${r.published ? 'upcoming' : 'draft'}`}>{r.published ? 'live' : 'draft'}</span> }]}
    fields={[
      { name: 'title', label: 'Headline', required: true }, { name: 'message', label: 'Message', type: 'textarea' },
      { name: 'date', label: 'Date', type: 'date', default: new Date().toISOString().slice(0, 10) },
      { name: 'pinned', label: 'Pin to top', type: 'checkbox' }, { name: 'published', label: 'Published', type: 'checkbox', default: true },
    ]} />
);
