import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { connectDB } from './config/db.js';
import { UPLOAD_DIR } from './middleware/upload.js';
import { crud } from './routes/crud.js';
import authRoutes from './routes/auth.js';
import mediaRoutes from './routes/media.js';
import contentRoutes from './routes/content.js';
import { Event, TeamMember, Sponsor, Announcement } from './models/index.js';
import formsRoutes from './routes/forms.js';
import publicFormsRoutes from './routes/publicForms.js';

if (!process.env.JWT_SECRET || !process.env.MONGO_URI) {
  console.error('Missing JWT_SECRET or MONGO_URI in .env'); process.exit(1);
}

const app = express();
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(',') || true }));
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d' }));

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api/auth', authRoutes);
app.use('/api/events', crud(Event, {
  sort: { date: -1 }, fileFields: { coverImage: 'coverImage' },
  publicFilter: { status: { $in: ['upcoming', 'past'] } }, publicSort: { date: 1 },
  booleans: ['registrationOpen', 'showInAnnouncements'], numbers: ['seats'],
}));
app.use('/api/media', mediaRoutes);
app.use('/api/team', crud(TeamMember, { sort: { order: 1, createdAt: 1 }, fileFields: { photo: 'photo' }, numbers: ['order'] }));
app.use('/api/sponsors', crud(Sponsor, { sort: { order: 1, createdAt: 1 }, fileFields: { logo: 'logo' }, numbers: ['order', 'logoZoom'] }));
app.use('/api/announcements', crud(Announcement, {
  sort: { pinned: -1, date: -1 }, publicFilter: { published: true }, booleans: ['pinned', 'published'],
}));
app.use('/api/content', contentRoutes);
app.use('/api/forms', formsRoutes);
app.use('/api/public/forms', publicFormsRoutes);

app.use((req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, _req, res, _next) => {
  console.error(err);
  const status = err.name === 'ValidationError' || err.name === 'MulterError' ||
  err.message === 'Unsupported file type' || /not supported/i.test(err.message) ? 400 : 500;  res.status(status).json({ error: status === 400 ? err.message : 'Server error' });
});

connectDB().then(() => {
  const port = process.env.PORT || 5000;
  app.listen(port, () => console.log(`API on http://localhost:${port}`));
}).catch((e) => { console.error('DB connection failed:', e.message); process.exit(1); });
