import multer from 'multer';
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';

export const UPLOAD_DIR = path.resolve('uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const IMAGE = ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.svg'];
const VIDEO = ['.mp4', '.mov', '.webm', '.m4v'];

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`);
  },
});

const fileFilter = (_req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase();
  if (IMAGE.includes(ext) || VIDEO.includes(ext)) return cb(null, true);
  cb(new Error('Unsupported file type'));
};

export const upload = multer({ storage, fileFilter, limits: { fileSize: 200 * 1024 * 1024 } });
export const mediaType = (name) => (VIDEO.includes(path.extname(name).toLowerCase()) ? 'video' : 'photo');
export const publicUrl = (file) => `/uploads/${file.filename}`;
export function removeUpload(url) {
  if (!url || !url.startsWith('/uploads/')) return;
  fs.unlink(path.join(UPLOAD_DIR, path.basename(url)), () => {});
}
// Per-form dynamic uploader: admin chooses allowed file types & max size per field.
// Usage: const up = createUploader({ allowedExts: ['.pdf', '.jpg'], maxSize: 5*1024*1024 });
export function createUploader({ allowedExts = null, maxSize = 10 * 1024 * 1024 } = {}) {
  const dynFilter = (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedExts && allowedExts.length && !allowedExts.includes(ext)) {
      return cb(new Error(`File type not supported (${ext}). Allowed: ${allowedExts.join(', ')}`));
    }
    cb(null, true);
  };
  return multer({ storage, fileFilter: dynFilter, limits: { fileSize: maxSize } });
}
