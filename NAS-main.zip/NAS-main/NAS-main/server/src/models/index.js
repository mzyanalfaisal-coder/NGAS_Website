import mongoose from 'mongoose';
const { Schema, model } = mongoose;
const opts = { timestamps: true };

export const Admin = model('Admin', new Schema({
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
}, opts));

export const Event = model('Event', new Schema({
  title: { type: String, required: true, trim: true },
  description: String,
  date: { type: Date, required: true },
  time: String,
  duration: String,
  venue: String,
  fee: String,
  seats: Number,
  included: String,
  coverImage: String,
  registrationLink: String,
  registrationOpen: { type: Boolean, default: true },
  status: { type: String, enum: ['upcoming', 'past', 'draft'], default: 'upcoming' },
  showInAnnouncements: { type: Boolean, default: false },
}, opts));

export const Media = model('Media', new Schema({
  event: { type: Schema.Types.ObjectId, ref: 'Event', required: true, index: true },
  type: { type: String, enum: ['photo', 'video'], required: true },
  url: { type: String, required: true },
}, opts));

export const TeamMember = model('TeamMember', new Schema({
  name: { type: String, required: true },
  designation: String,
  domain: String,
  linkedin: String,
  photo: String,
  order: { type: Number, default: 0 },
}, opts));

export const Sponsor = model('Sponsor', new Schema({
  name: { type: String, required: true },
  logo: String,
  logoFocus: { type: String, default: '50% 50%' }, // point the logo zooms into
  logoZoom: { type: Number, default: 1, min: 1, max: 4 },
  website: String,
  note: String,
  order: { type: Number, default: 0 },
}, opts));

export const Announcement = model('Announcement', new Schema({
  title: { type: String, required: true },
  message: String,
  date: { type: Date, default: Date.now },
  pinned: { type: Boolean, default: false },
  published: { type: Boolean, default: true },
}, opts));

export const ContactMessage = model('ContactMessage', new Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  subject: String,
  message: { type: String, required: true },
  read: { type: Boolean, default: false },
}, opts));

export const SiteContent = model('SiteContent', new Schema({
  key: { type: String, default: 'main', unique: true },
  heroHeadline: String,
  heroSub: String,
  heroImage: String,
  heroFocus: { type: String, default: '50% 50%' }, // CSS background-position chosen by admin
  stats: [{ value: String, label: String }],
  aboutHeading: String,
  aboutText: String,
  aboutImage: String,
  vision: String,
  mission: String,
  faqs: [{ q: String, a: String }],
  contact: {
    email: String, phone: String, address: String, hours: String,
    instagram: String, linkedin: String, facebook: String, youtube: String,
  },
}, opts));
// ─── Form Builder ──────────────────────────────────────────────
const FieldSchema = new Schema({
  id: { type: String, required: true },           // e.g. "field_001"
  type: { type: String, required: true },         // shortText, longText, email, ...
  label: { type: String, required: true },
  description: String,
  required: { type: Boolean, default: false },
  placeholder: String,
  defaultValue: String,
  options: [String],                              // dropdown / multipleChoice / checkboxes
  min: Number, max: Number,                       // number, rating, length
  minLength: Number, maxLength: Number,
  fileTypes: [String],                            // e.g. [".pdf", ".jpg"]
  maxFileSize: Number,                            // bytes
  minDate: String, maxDate: String,               // ISO strings
  errorMessage: String,                           // custom validation message
  sectionTitle: String,                           // for type "section"
}, { _id: false });

export const Form = model('Form', new Schema({
  title: { type: String, required: true, trim: true },
  slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
  description: String,
  eventName: String,
  eventDate: Date,
  eventLocation: String,
  coverImage: String,
  registrationDeadline: Date,
  status: { type: String, enum: ['draft', 'published', 'closed'], default: 'draft' },
  closesAt: Date,                                 // optional auto-close
  fields: [FieldSchema],
  createdBy: { type: Schema.Types.ObjectId, ref: 'Admin' },
}, opts));


export const FormSubmission = model('FormSubmission', new Schema({
  formId: { type: Schema.Types.ObjectId, ref: 'Form', required: true, index: true },
  responses: [{
    fieldId: { type: String, required: true },
    value: Schema.Types.Mixed,                    // string | number | array | file path
    _id: false,
  }],
  files: [{ fieldId: String, url: String, originalName: String, size: Number, _id: false }],
  submittedAt: { type: Date, default: Date.now, index: true },
  ip: String,
  userAgent: String,
}, opts));
