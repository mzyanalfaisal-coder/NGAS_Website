import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import { Admin } from '../models/index.js';
import { requireAdmin } from '../middleware/auth.js';

const r = Router();
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true });

r.post('/login', limiter, async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const admin = await Admin.findOne({ email: String(email || '').toLowerCase() });
    if (!admin || !(await bcrypt.compare(String(password || ''), admin.passwordHash)))
      return res.status(401).json({ error: 'Invalid email or password' });
    const token = jwt.sign({ id: admin._id, email: admin.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, email: admin.email });
  } catch (e) { next(e); }
});

r.get('/me', requireAdmin, (req, res) => res.json({ email: req.admin.email }));

r.post('/change-password', requireAdmin, async (req, res, next) => {
  try {
    const { current, next: nw } = req.body;
    if (!nw || nw.length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters' });
    const admin = await Admin.findById(req.admin.id);
    if (!(await bcrypt.compare(String(current || ''), admin.passwordHash)))
      return res.status(400).json({ error: 'Current password is incorrect' });
    admin.passwordHash = await bcrypt.hash(nw, 12);
    await admin.save();
    res.json({ ok: true });
  } catch (e) { next(e); }
});
export default r;
