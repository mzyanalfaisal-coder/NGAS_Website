import { Router } from 'express';
import { SiteContent, ContactMessage } from '../models/index.js';
import { requireAdmin } from '../middleware/auth.js';
import { upload, publicUrl, removeUpload } from '../middleware/upload.js';
import rateLimit from 'express-rate-limit';

const r = Router();
const get = async () => (await SiteContent.findOne({ key: 'main' })) || (await SiteContent.create({ key: 'main' }));

r.get('/', async (_req, res, next) => { try { res.json(await get()); } catch (e) { next(e); } });

// multipart: JSON in `data`, optional files heroImage / aboutImage
r.put('/', requireAdmin, upload.fields([{ name: 'heroImage', maxCount: 1 }, { name: 'aboutImage', maxCount: 1 }]), async (req, res, next) => {
  try {
    const doc = await get();
    const data = req.body.data ? JSON.parse(req.body.data) : req.body;
    delete data._id;
    for (const f of ['heroImage', 'aboutImage']) {
      const file = req.files?.[f]?.[0];
      if (file) { removeUpload(doc[f]); data[f] = publicUrl(file); } else delete data[f];
    }
    doc.set(data);
    res.json(await doc.save());
  } catch (e) { next(e); }
});

// Contact form (public) + inbox (admin)
const msgLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 10 });
r.post('/messages', msgLimiter, async (req, res, next) => {
  try {
    const { name, email, subject, message } = req.body;
    if (!name || !email || !message) return res.status(400).json({ error: 'Name, email and message are required' });
    await ContactMessage.create({ name, email, subject, message });
    res.status(201).json({ ok: true });
  } catch (e) { next(e); }
});
r.get('/messages', requireAdmin, async (_req, res, next) => {
  try { res.json(await ContactMessage.find().sort({ createdAt: -1 })); } catch (e) { next(e); }
});
r.patch('/messages/:id', requireAdmin, async (req, res, next) => {
  try { res.json(await ContactMessage.findByIdAndUpdate(req.params.id, { read: !!req.body.read }, { new: true })); } catch (e) { next(e); }
});
r.delete('/messages/:id', requireAdmin, async (req, res, next) => {
  try { await ContactMessage.findByIdAndDelete(req.params.id); res.json({ ok: true }); } catch (e) { next(e); }
});
export default r;
