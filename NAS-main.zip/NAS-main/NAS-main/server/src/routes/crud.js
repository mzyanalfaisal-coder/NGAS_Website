import { Router } from 'express';
import { requireAdmin } from '../middleware/auth.js';
import { upload, publicUrl, removeUpload } from '../middleware/upload.js';

// Generic CRUD router. Public: list/get. Admin: create/update/delete.
// fileFields: { formFieldName: 'modelFieldName' } for single-image uploads.
export function crud(Model, { sort = { createdAt: -1 }, fileFields = {}, publicFilter, publicSort, booleans = [], numbers = [] } = {}) {
  const r = Router();
  const uploader = upload.fields(Object.keys(fileFields).map((name) => ({ name, maxCount: 1 })));

  const body = (req, existing) => {
    const data = { ...req.body };
    for (const b of booleans) if (b in data) data[b] = data[b] === true || data[b] === 'true';
    for (const n of numbers) if (n in data) data[n] = data[n] === '' ? undefined : Number(data[n]);
    for (const [field, target] of Object.entries(fileFields)) {
      const f = req.files?.[field]?.[0];
      delete data[field]; // before assigning, since field and target often share a name
      if (f) { if (existing?.[target]) removeUpload(existing[target]); data[target] = publicUrl(f); }
    }
    delete data._id;
    return data;
  };

  // ?all=1 returns drafts/unpublished too, so it is admin-only
  r.get('/', (req, res, next) => (req.query.all === '1' ? requireAdmin(req, res, next) : next()), async (req, res, next) => {
    try {
      const isAdmin = req.query.all === '1';
      const q = isAdmin ? {} : (publicFilter || {});
      res.json(await Model.find(q).sort(isAdmin ? sort : (publicSort || sort)));
    } catch (e) { next(e); }
  });
  r.get('/:id', async (req, res, next) => {
    try {
      const doc = await Model.findById(req.params.id);
      doc ? res.json(doc) : res.status(404).json({ error: 'Not found' });
    } catch (e) { next(e); }
  });
  r.post('/', requireAdmin, uploader, async (req, res, next) => {
    try { res.status(201).json(await Model.create(body(req))); } catch (e) { next(e); }
  });
  r.put('/:id', requireAdmin, uploader, async (req, res, next) => {
    try {
      const doc = await Model.findById(req.params.id);
      if (!doc) return res.status(404).json({ error: 'Not found' });
      doc.set(body(req, doc));
      res.json(await doc.save());
    } catch (e) { next(e); }
  });
  r.delete('/:id', requireAdmin, async (req, res, next) => {
    try {
      const doc = await Model.findByIdAndDelete(req.params.id);
      if (!doc) return res.status(404).json({ error: 'Not found' });
      for (const t of Object.values(fileFields)) removeUpload(doc[t]);
      res.json({ ok: true });
    } catch (e) { next(e); }
  });
  return r;
}
