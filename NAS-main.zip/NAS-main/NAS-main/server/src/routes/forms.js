import { Router } from 'express';
import { Form, FormSubmission } from '../models/index.js';
import { requireAdmin } from '../middleware/auth.js';
import { upload, publicUrl, removeUpload } from '../middleware/upload.js';

const r = Router();

const slugify = (s) =>
  String(s || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80) || `form-${Date.now()}`;

async function uniqueSlug(base, ignoreId = null) {
  let slug = slugify(base);
  let n = 1;
  while (true) {
    const existing = await Form.findOne({ slug, ...(ignoreId ? { _id: { $ne: ignoreId } } : {}) }).select('_id');
    if (!existing) return slug;
    slug = `${slugify(base)}-${++n}`;
  }
}

const coverUploader = upload.single('coverImage');
const formSelect = '-__v';

// List all forms
r.get('/', requireAdmin, async (_req, res, next) => {
  try {
    const forms = await Form.find().sort({ updatedAt: -1 }).select(formSelect).lean();
    const counts = await FormSubmission.aggregate([{ $group: { _id: '$formId', n: { $sum: 1 } } }]);
    const map = Object.fromEntries(counts.map((c) => [String(c._id), c.n]));
    res.json(forms.map((f) => ({ ...f, responseCount: map[String(f._id)] || 0 })));
  } catch (e) { next(e); }
});

// Get single form
r.get('/:id', requireAdmin, async (req, res, next) => {
  try {
    const form = await Form.findById(req.params.id).select(formSelect);
    if (!form) return res.status(404).json({ error: 'Form not found' });
    const responseCount = await FormSubmission.countDocuments({ formId: form._id });
    res.json({ ...form.toObject(), responseCount });
  } catch (e) { next(e); }
});

// Create form
r.post('/', requireAdmin, coverUploader, async (req, res, next) => {
  try {
    const data = { ...req.body };
    if (data.fields) data.fields = typeof data.fields === 'string' ? JSON.parse(data.fields) : data.fields;
    delete data._id;
    delete data.slug;
    const base = data.title || 'Untitled Form';
    data.slug = await uniqueSlug(base);
    if (req.file) data.coverImage = publicUrl(req.file);
    data.createdBy = req.admin.id;
    const form = await Form.create(data);
    res.status(201).json(form);
  } catch (e) { next(e); }
});

// Update form
r.put('/:id', requireAdmin, coverUploader, async (req, res, next) => {
  try {
    const form = await Form.findById(req.params.id);
    if (!form) return res.status(404).json({ error: 'Form not found' });
    const data = { ...req.body };
    if (data.fields) data.fields = typeof data.fields === 'string' ? JSON.parse(data.fields) : data.fields;
    delete data._id;
    delete data.slug;
    delete data.createdBy;
    if (req.file) {
      if (form.coverImage) removeUpload(form.coverImage);
      data.coverImage = publicUrl(req.file);
    }
    form.set(data);
    res.json(await form.save());
  } catch (e) { next(e); }
});

// Delete form
r.delete('/:id', requireAdmin, async (req, res, next) => {
  try {
    const form = await Form.findByIdAndDelete(req.params.id);
    if (!form) return res.status(404).json({ error: 'Form not found' });
    if (form.coverImage) removeUpload(form.coverImage);
    const subs = await FormSubmission.find({ formId: form._id });
    subs.forEach((s) => (s.files || []).forEach((f) => removeUpload(f.url)));
    await FormSubmission.deleteMany({ formId: form._id });
    res.json({ ok: true, deletedResponses: subs.length });
  } catch (e) { next(e); }
});

// Duplicate form
r.post('/:id/duplicate', requireAdmin, async (req, res, next) => {
  try {
    const src = await Form.findById(req.params.id).lean();
    if (!src) return res.status(404).json({ error: 'Form not found' });
    delete src._id;
    src.title = `${src.title} — Copy`;
    src.slug = await uniqueSlug(src.title);
    src.status = 'draft';
    src.createdBy = req.admin.id;
    const copy = await Form.create(src);
    res.status(201).json(copy);
  } catch (e) { next(e); }
});

// Status changes
r.post('/:id/publish', requireAdmin, async (req, res, next) => {
  try {
    const f = await Form.findByIdAndUpdate(req.params.id, { status: 'published' }, { new: true });
    if (!f) return res.status(404).json({ error: 'Form not found' });
    res.json(f);
  } catch (e) { next(e); }
});

r.post('/:id/unpublish', requireAdmin, async (req, res, next) => {
  try {
    const f = await Form.findByIdAndUpdate(req.params.id, { status: 'draft' }, { new: true });
    if (!f) return res.status(404).json({ error: 'Form not found' });
    res.json(f);
  } catch (e) { next(e); }
});

r.post('/:id/close', requireAdmin, async (req, res, next) => {
  try {
    const f = await Form.findByIdAndUpdate(req.params.id, { status: 'closed' }, { new: true });
    if (!f) return res.status(404).json({ error: 'Form not found' });
    res.json(f);
  } catch (e) { next(e); }
});
// ── Get all responses for a form ──────────────────────────────
r.get('/:id/responses', requireAdmin, async (req, res, next) => {
  try {
    const responses = await FormSubmission.find({ formId: req.params.id }).sort({ submittedAt: -1 });
    res.json(responses);
  } catch (e) { next(e); }
});

// ── Delete a single response ──────────────────────────────────
r.delete('/:id/responses/:responseId', requireAdmin, async (req, res, next) => {
  try {
    const response = await FormSubmission.findOneAndDelete({ 
      _id: req.params.responseId, 
      formId: req.params.id 
    });
    if (!response) return res.status(404).json({ error: 'Response not found' });
    res.json({ ok: true });
  } catch (e) { next(e); }
});
export default r;