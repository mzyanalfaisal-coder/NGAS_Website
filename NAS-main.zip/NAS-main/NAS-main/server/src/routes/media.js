import { Router } from 'express';
import { Media } from '../models/index.js';
import { requireAdmin } from '../middleware/auth.js';
import { upload, mediaType, publicUrl, removeUpload } from '../middleware/upload.js';

const r = Router();

// Public: ?event=<id>&type=photo|video&page=1&limit=24  (no event = all)
r.get('/', async (req, res, next) => {
  try {
    const { event, type } = req.query;
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(60, Number(req.query.limit) || 24);
    const q = {};
    if (event && event !== 'all') q.event = event;
    if (type === 'photo' || type === 'video') q.type = type;
    const [items, total] = await Promise.all([
      Media.find(q).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).populate('event', 'title date'),
      Media.countDocuments(q),
    ]);
    res.json({ items, total, page, pages: Math.ceil(total / limit) });
  } catch (e) { next(e); }
});

// Counts per event (for dropdown/cards)
r.get('/counts', async (_req, res, next) => {
  try {
    const rows = await Media.aggregate([{ $group: { _id: { event: '$event', type: '$type' }, n: { $sum: 1 } } }]);
    const out = {};
    for (const { _id, n } of rows) {
      const k = String(_id.event);
      out[k] ??= { photo: 0, video: 0 };
      out[k][_id.type] = n;
    }
    res.json(out);
  } catch (e) { next(e); }
});

r.post('/', requireAdmin, upload.array('files', 30), async (req, res, next) => {
  try {
    if (!req.body.event) return res.status(400).json({ error: 'Choose an event first' });
    const docs = await Media.insertMany((req.files || []).map((f) => ({
      event: req.body.event, type: mediaType(f.originalname), url: publicUrl(f),
    })));
    res.status(201).json(docs);
  } catch (e) { next(e); }
});

r.post('/bulk-delete', requireAdmin, async (req, res, next) => {
  try {
    const ids = req.body.ids || [];
    const docs = await Media.find({ _id: { $in: ids } });
    docs.forEach((d) => removeUpload(d.url));
    await Media.deleteMany({ _id: { $in: ids } });
    res.json({ deleted: docs.length });
  } catch (e) { next(e); }
});

r.post('/bulk-move', requireAdmin, async (req, res, next) => {
  try {
    const { ids = [], event } = req.body;
    const out = await Media.updateMany({ _id: { $in: ids } }, { event });
    res.json({ moved: out.modifiedCount });
  } catch (e) { next(e); }
});
export default r;
