import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { Form, FormSubmission } from '../models/index.js';
import { createUploader, publicUrl } from '../middleware/upload.js';

const r = Router();

const submitLimiter = rateLimit({ windowMs: 60 * 1000, max: 20, standardHeaders: true });

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phoneRe = /^[+]?[\d\s\-()]{7,20}$/;

const isClosed = (form) => {
  if (form.status === 'closed') return true;
  const now = Date.now();
  if (form.closesAt && new Date(form.closesAt).getTime() < now) return true;
  if (form.registrationDeadline && new Date(form.registrationDeadline).getTime() < now) return true;
  return false;
};

function validateField(field, value) {
  const err = field.errorMessage || null;
  const empty = value === undefined || value === null || value === '' || (Array.isArray(value) && value.length === 0);
  if (field.required && empty) return err || 'This field is required.';
  if (empty) return null;

  const v = String(value);
  switch (field.type) {
    case 'email':
      if (!emailRe.test(v)) return err || 'Please enter a valid email address.';
      break;
    case 'phone':
      if (!phoneRe.test(v)) return err || 'Please enter a valid phone number.';
      break;
    case 'number':
    case 'rating': {
      const n = Number(v);
      if (Number.isNaN(n)) return err || 'Please enter a valid number.';
      if (field.min != null && n < field.min) return err || `Minimum value is ${field.min}.`;
      if (field.max != null && n > field.max) return err || `Maximum value is ${field.max}.`;
      break;
    }
    case 'shortText':
    case 'longText':
      if (field.minLength != null && v.length < field.minLength) return err || `Minimum ${field.minLength} characters.`;
      if (field.maxLength != null && v.length > field.maxLength) return err || `Maximum ${field.maxLength} characters.`;
      break;
    case 'dropdown':
    case 'multipleChoice': {
      const opts = field.options || [];
      if (opts.length && !opts.includes(v)) return err || 'Please choose a valid option.';
      break;
    }
    case 'checkboxes': {
      const arr = Array.isArray(value) ? value : [value];
      const opts = field.options || [];
      if (opts.length && arr.some((x) => !opts.includes(x))) return err || 'Please choose a valid option.';
      break;
    }
    case 'date': {
      const d = new Date(v);
      if (Number.isNaN(d.getTime())) return err || 'Please choose a valid date.';
      if (field.minDate && d < new Date(field.minDate)) return err || `Date must be on or after ${field.minDate}.`;
      if (field.maxDate && d > new Date(field.maxDate)) return err || `Date must be on or before ${field.maxDate}.`;
      break;
    }
    case 'consent':
      if (value !== true && value !== 'true') return err || 'You must agree to continue.';
      break;
    default:
      break;
  }
  return null;
}

r.get('/:slug', async (req, res, next) => {
  try {
    const form = await Form.findOne({ slug: req.params.slug, status: { $in: ['published', 'closed'] } }).select('-__v');
    if (!form) return res.status(404).json({ error: 'Form not found' });
    res.json({ ...form.toObject(), closed: isClosed(form) });
  } catch (e) { next(e); }
});

r.post('/:slug/submit', submitLimiter, (req, res, next) => {
  Form.findOne({ slug: req.params.slug, status: { $in: ['published', 'closed'] } })
    .then((form) => {
      if (!form) return res.status(404).json({ error: 'Form not found' });
      if (isClosed(form)) return res.status(410).json({ error: 'Registration closed', closed: true });

      const fileFields = (form.fields || []).filter((f) => f.type === 'file');
      const allowedExts = new Set();
      fileFields.forEach((f) => (f.fileTypes || []).forEach((ext) => allowedExts.add(ext.toLowerCase())));
      const maxSize = fileFields.reduce((m, f) => Math.min(m, f.maxFileSize || 10 * 1024 * 1024), 10 * 1024 * 1024);

      const up = createUploader({
        allowedExts: allowedExts.size ? [...allowedExts] : null,
        maxSize,
      });
      up.fields(fileFields.map((f) => ({ name: f.id, maxCount: 1 })))(req, res, async (err) => {
        if (err) return next(err);
        try {
          const data = { ...req.body };
          const responses = [];
          const files = [];
          const errors = {};

          for (const f of form.fields || []) {
            if (f.type === 'section') continue;
            let val;
            if (f.type === 'file') {
              const fObj = req.files?.[f.id]?.[0];
              if (fObj) {
                const allowed = (f.fileTypes || []).map((x) => x.toLowerCase());
                if (allowed.length && !allowed.includes('.' + fObj.originalname.split('.').pop().toLowerCase())) {
                  errors[f.id] = `File type not supported. Allowed: ${allowed.join(', ')}`;
                  continue;
                }
                if (f.maxFileSize && fObj.size > f.maxFileSize) {
                  errors[f.id] = `File too large. Max ${Math.round(f.maxFileSize / 1024 / 1024)} MB.`;
                  continue;
                }
                const url = publicUrl(fObj);
                files.push({ fieldId: f.id, url, originalName: fObj.originalname, size: fObj.size });
                responses.push({ fieldId: f.id, value: url });
                continue;
              }
              val = undefined;
            } else if (f.type === 'checkboxes') {
              val = data[f.id];
              if (typeof val === 'string') {
                try { val = JSON.parse(val); } catch { val = [val]; }
              }
            } else if (f.type === 'consent') {
              val = data[f.id] === 'true' || data[f.id] === true;
            } else {
              val = data[f.id];
            }

            const msg = validateField(f, val);
            if (msg) { errors[f.id] = msg; continue; }
            if (val !== undefined && val !== '' && !(Array.isArray(val) && !val.length)) {
              responses.push({ fieldId: f.id, value: val });
            }
          }

          if (Object.keys(errors).length) {
            return res.status(400).json({ error: 'Validation failed', fields: errors });
          }

          const doc = await FormSubmission.create({
            formId: form._id,
            responses,
            files,
            ip: req.ip,
            userAgent: req.get('user-agent') || '',
          });
          res.status(201).json({ ok: true, submissionId: doc._id });
        } catch (e) { next(e); }
      });
    })
    .catch(next);
});
// ── List all published forms (for Website) ───────────────────
r.get('/', async (_req, res, next) => {
  try {
    const forms = await Form.find({ status: 'published' })
      .select('title slug eventName eventDate description')
      .sort({ createdAt: -1 });
    res.json(forms);
  } catch (e) { next(e); }
});

export default r;