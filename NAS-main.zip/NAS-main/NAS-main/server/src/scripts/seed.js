import 'dotenv/config';
import bcrypt from 'bcryptjs';
import mongoose from 'mongoose';
import { Admin, Event, TeamMember, Sponsor, Announcement, SiteContent } from '../models/index.js';

await mongoose.connect(process.env.MONGO_URI);
const email = (process.env.ADMIN_EMAIL || 'admin@nas.neduet.edu.pk').toLowerCase();
await Admin.findOneAndUpdate({ email }, { passwordHash: await bcrypt.hash(process.env.ADMIN_PASSWORD || 'ChangeMe123!', 12) }, { upsert: true });
console.log('Admin ready:', email);

if (process.argv.includes('--sample')) {
  await Promise.all([Event.deleteMany(), TeamMember.deleteMany(), Sponsor.deleteMany(), Announcement.deleteMany()]);
  const d = (s) => new Date(s);
  await Event.insertMany([
    { title: 'Karachi Coastal Cleanup & Cycling', date: d('2026-11-15'), time: '7:00 AM', venue: 'Hawke’s Bay, Karachi', duration: '1 day', fee: 'Free for members', seats: 60, description: 'Sunrise cycling ride along the coast followed by a beach cleanup drive.', status: 'upcoming', registrationLink: 'https://forms.gle/example', showInAnnouncements: true },
    { title: 'Hunza Valley Photography Expedition', date: d('2026-11-29'), venue: 'Hunza, Gilgit-Baltistan', duration: '6 days', status: 'upcoming', registrationLink: 'https://forms.gle/example' },
    { title: 'Skardu Winter Trek', date: d('2026-12-20'), venue: 'Skardu, Gilgit-Baltistan', duration: '5 days', fee: 'PKR 18,500', seats: 40, status: 'upcoming', registrationLink: 'https://forms.gle/example' },
    { title: 'Kund Malir Beach Camp', date: d('2026-10-04'), venue: 'Balochistan Coast', duration: '2 days', status: 'past' },
    { title: 'Ormara Road Trip', date: d('2026-08-16'), venue: 'Makran Coastal Highway', duration: '3 days', status: 'past' },
    { title: 'Kirthar Hiking Day', date: d('2026-03-08'), venue: 'Kirthar National Park', duration: '1 day', status: 'past' },
  ]);
  await TeamMember.insertMany([
    ['Ayesha Siddiqui', 'President', 'Leadership'], ['Hamza Ali', 'Vice President', 'Leadership'],
    ['Fatima Noor', 'General Secretary', 'Management'], ['Usman Raza', 'Head of Media', 'Media'],
  ].map(([name, designation, domain], i) => ({ name, designation, domain, order: i, linkedin: 'https://linkedin.com' })));
  await Sponsor.insertMany(['Sponsor One', 'Sponsor Two', 'Sponsor Three', 'Sponsor Four', 'Sponsor Five', 'Sponsor Six'].map((name, order) => ({ name, order })));
  await Announcement.insertMany([
    { title: 'Skardu Winter Trek registrations close Dec 5', message: 'Seats are limited to 40 participants.', pinned: true },
    { title: 'Core team applications open for 2027', message: 'Apply through the Contact page before Nov 20.' },
  ]);
  console.log('Sample data inserted');
}

await SiteContent.findOneAndUpdate({ key: 'main' }, { $setOnInsert: {
  key: 'main',
  heroHeadline: 'Adventure starts where the classroom ends.',
  heroSub: 'Treks, road trips, camps and community drives — join NED’s home for explorers and build memories far beyond campus.',
  stats: [{ value: '40+', label: 'Expeditions' }, { value: '1,200+', label: 'Members' }, { value: '15', label: 'Sponsors' }],
  aboutHeading: 'A society that turns weekends into expeditions.',
  aboutText: 'Ned Adventure Society organises treks, camps, road trips and community drives across Pakistan, with safety training, local guides and a strong team culture.',
  vision: 'To be the most trusted student adventure community in Pakistan, inspiring a generation to explore responsibly and lead with confidence.',
  mission: 'To organise safe, affordable and unforgettable outdoor experiences that build teamwork, resilience and respect for nature.',
  faqs: [
    { q: 'Who can join NAS?', a: 'Any currently enrolled NEDUET student can become a member.' },
    { q: 'How do I register for an event?', a: 'Open the event on the Events page, expand its card and press Register Now.' },
    { q: 'How can my company sponsor NAS?', a: 'Reach out through the Contact page and we will share our sponsorship proposal.' },
  ],
  contact: { email: 'nas@neduet.edu.pk', phone: '+92 300 0000000', address: 'NED University of Engineering & Technology, University Road, Karachi', hours: 'Mon – Fri · 10:00 AM – 4:00 PM' },
} }, { upsert: true });
console.log('Site content ready');
await mongoose.disconnect();
